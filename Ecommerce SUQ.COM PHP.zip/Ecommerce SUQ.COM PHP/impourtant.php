------------------connection-------------------------------
<?php

try {
 $connection=new pdo("mysql:host=localhost;dbname=suq;charset=utf8", "root", "");

 $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);



} catch (Exception $e) 
{
  $e->getMessage();
}




?> 
************************************************************************************************
++++commandesocas.php++++++++
<?php

function ajouter($image, $nom, $prix, $description,$categorie,$etat,$posteur,$contact)
{
 if(require("cnct.php"))
 {
   $req = $access->prepare("INSERT INTO produitsocas (image, nom, prix, description,categorie,etat,posteur,contact) VALUES ('$image', '$nom', $prix, '$description','$categorie','$etat','$posteur','$contact'");

   $req->execute(array($image, $nom, $prix, $description,$categorie,$etat,$posteur,$contact));

   $req->closeCursor();
 }
}

function afficher()
{
	if(require("cnct.php"))
	{
		$req=$access->prepare("SELECT * FROM produitsocas ORDER BY id DESC");

    $req->execute();

    $data = $req->fetchAll(PDO::FETCH_OBJ);

    return $data;

    $req->closeCursor();
  }
}
function supprimer($id)
{
	if(require("cnct.php"))
	{
		$req=$access->prepare("DELETE FROM produitsocas WHERE id=?");

		$req->execute(array($nom));

		$req->closeCursor();
	}
}

?>
**********************************************************************************
++++commandesneuf.php++
<?php

function ajouter($image, $nom, $prix, $description,$categorie)
{
 if(require("cnct.php"))
 {
   $req = $access->prepare("INSERT INTO produitneuf (image, nom, prix, description,categorie,) VALUES ('$image', '$nom', $prix, '$description'),'$categorie'");

   $req->execute(array($image, $nom, $prix, $description,$categorie));

   $req->closeCursor();
 }
}

function afficher()
{
	if(require("cnct.php"))
	{
		$req=$access->prepare("SELECT * FROM produitneuf ORDER BY id DESC");

    $req->execute();

    $data = $req->fetchAll(PDO::FETCH_OBJ);

    return $data;

    $req->closeCursor();
  }
}
function supprimer($id)
{
	if(require("cnct.php"))
	{
		$req=$access->prepare("DELETE FROM produitneuf WHERE id=?");

		$req->execute(array($nom));

		$req->closeCursor();
	}
}

?>
*************************************************************************
+++++cmdmembres.php+++++++++++

<?php 




function ajouter($email, $password, $nom, $prenom,$jour,$mois,$annee,$numero,$adress)
{
  if(require("cnct.php"))
  {
   $req = $access->prepare("INSERT INTO abonnee (email,password,nom,prenom,jour,mois,annee,numero,adress) VALUES ('$email', '$password', '$nom', '$prenom','$jour','$mois','$annee','$numero','$adress'");

   $req->execute(array($email, $password, $nom, $prenom,$jour,$annee,$numero,$adress
   ));

   $req->closeCursor();
 }}
 ?>

 ***************************************************************************
 ++++++ins.php---


 <?php
 srand(time(0));
 include('cnct.php');


 

 $rp= $access ->prepare('INSERT INTO abonnee VALUES(:email ,:password ,:nom,:prenom,:jour,:mois,:annee,:numero, :adress)');

 $rp->execute(array(
   'email' => $_POST['email'],
   'password' => $_POST['password'] , 
   'nom' => $_POST['nom'] ,
   'prenom' => $_POST['prenom'] ,
   'jour' => $_POST['jour'] , 
   'mois' => $_POST['mois'] ,
   'annee' => $_POST['annee'] , 
   'numero' => $_POST['numero'] ,
   'adress' => $_POST['adress'] 
 ));	






 

 ?>
 ********************************************
 -----login.php---------

 <?php 
 session_start();


 require("cnct.php" );
 $condidats=$bdd->quiry("SELECT email,password  FROM abonnee");
 $trouve=false;
 while($tuple=$abonnee->fetch())
 {
   if($_POST['email']==$tuple['email'] &&$_POST['password']==$tuple['password']){


    $trouve=true;break;

  }
}
if($trouve==true){
  header("Location:conditionUtilisation.php");
  $_SESSION['connected']=true;
  $_SESSION['email']=$_POST['email'];

}else{
  header("Location:login.php");
  $_SESSION['connected']=false;
}




?>
*****************************************


<?php if (isset($_POST['send'])) {

  $email = escape_string($_POST['email']);
  $password =escape_string(sha1($_POST['password']));
  $nom =   escape_string($_POST['nom']); 
  $prenom = escape_string($_POST['prenom']); 
  $jour = escape_string($_POST['jour']);
  $mois = escape_string($_POST['mois']);
  $annee = escape_string($_POST['annee']);
  $numero = escape_string($_POST['numero']);
  $adress = escape_string($_POST['adress']);
  $sql="INSERT INTO abonnee VALUES('','$email','$password','$nom','$prenom','$jour','$mois','$annee','$numero','$adress')";
  if (query($sql)) {
    echo "succé";
  }else{
   echo "ereur";
 }
}

?>

<form  class="flex-center column right" method="post" action="ins.php">
  <h2 class="title">M'inscrire !</h2>
  <div class="form-segments-wrapper">
    <div class="form-segments-content flex">

      <div class="form-segment">
        <div class="form-input-wrapper">
          <input type="text" name="email" id="email"  placeholder=" " required>
          <label for="email">Email</label>
        </div>

        <div class="form-input-wrapper">
          <input type="password" name="password" id="password"  placeholder=" " required>
          <label for="password">Mot de passe</label>
        </div>
                        <!-- <div class="form-input-wrapper">
                            <input type="password-confirm" name="password-confirm" id="password-confirm"  placeholder=" " required>
                            <label for="password-confirm">Confirmer votre mot de passe</label>
                          </div> -->
                          <button class="long-btn-r bg-green next-btn">Suivant</button>



                        </div>
                        <div class="form-segment">

                          <div class="form-input-wrapper">
                            <input type="text" name="nom" id="nom"  placeholder=" " required>
                            <label for="nom">Nom</label>
                          </div>
                          <div class="form-input-wrapper">
                            <input type="text" name="prenom" id="prenom"  placeholder=" " required>
                            <label for="prenom">prenom</label>
                          </div>
                          <div class="birthday-wrapper">
                            <p class="white birth-label">
                              <span>
                                Date de naissance
                              </span>
                            </p>

                            <div class="inputs-wrapper flex jc-space-between  wrap__">
                              <div class="form-input-wrapper">
                                <input type="number" name="jour" id="jour" min="1" max="31"  placeholder=" " required>
                                <label for="jour">Jour</label>
                              </div>
                              <div class="form-input-wrapper">
                                <input type="number" name="mois" id="mois" min="1" max="12"  placeholder=" " required>
                                <label for="Mois">Mois</label>
                              </div>
                              <div class="form-input-wrapper">
                                <input type="number" name="annee" id="annee" min="1"   placeholder=" " required>
                                <label for="annee">Année</label>
                              </div>
                            </div>



                          </div>

                          <button class="long-btn-r bg-green next-btn">Suivant</button>
                          <button class="long-btn return-btn flex center-align r3">
                            <span class="return-back-icon"></span>
                          revenir en arriere</button>
                        </div>


                        <div class="form-segment">
                          <div class="form-input-wrapper">
                            <input type="text" name="numero" id="numero"  placeholder=" " required>
                            <label for="numero">numero tel</label>
                          </div>

                          <div class="form-input-wrapper">
                            <input type="adresse" name="adress" id="adress"  placeholder=" " required>
                            <label for="adress">adresse</label>
                          </div>

                          <button class="long-btn-r bg-green"  id="valider" name="send" value="valider">Valider</button>

                          <button class="long-btn return-btn flex center-align r3">
                            <span class="return-back-icon"></span>
                          revenir en arriere</button>

                        </div>

                      </div>
                    </div>



                  </form>

                  *************************
                  <?php if (isset($_POST['vali'])) {

                    $email = escape_string($_POST['email']);
                    $password =escape_string(sha1($_POST['password']));


                    $sql=" SELECT * FROM abonnee WHERE email='$email' AND password='$password' LIMIT 1 ";
        // LIMIT 1 cest une facon de dire je veut en retourner 1 seul
                    $result=query($sql);
                    $user=fetch_array($result);
                    if ($user!= null)  {
                      $_SESSION['logged']=true;
                      $_SESSION['nom']=$user['nom'];
                      $_SESSION['id']=$user['id'];
                      print_r($user);
                    }else{
                     echo "email ou mot de passe incorrect";
                   }
                 }

                 ?> 
                 *************************************************************

                 <header class="container flex">
                  <a href="" class="logo">
                   <span class="text-primary " style="color: blue; font-size:1.5em; font-family:cursive;font-style: oblique;font-weight:bold;text-shadow:red;">      
                   SUUQ.com </span>
                 </a>
                 <nav class="flex-center">
                  <ul class="menu flex center-align">
                    <button class="x-btn flex-center"></button>
                    <li class="li"><a href="index.php">Acceuil</a></li>
                    <li class="li"><a href="categories.php">Categories</a></li>
                    <li class="global">
                      <a class="btn">Produits</a>

                      <ul class="sub-menu">
                        <li><a href="produitsNeufs.php">Neufs</a></li>
                        <li><a href="produitsOccas.php">Occasion</a></li>

                      </ul>
                    </li>
                    <li class="li"><a href="contact.php">Nous Contacter</a></li>

                    <li>
                      <a href="profil.html" class="profil-icon to-hide-desktop">profil</a>
                    </li>

                    <li>
                      <a href="rechercher.html" class="search-icon to-hide-desktop">rechercher</a>
                    </li>

                    <li>
                      <input type="checkbox" id="scheme-checkbox" />
                      <div class="scheme-label-wrapper iflex center-align">
                        <label for="scheme-checkbox" class="ib btn"></label>
                      </div>

                    </li>
                  </ul>


                  <a href="ins.php" class="long-btn-r bg-blue">Compte</a>
                  <a href="profil.php" class="profil-icon to-hide-mobile">profil</a>
                  <a href="rechercher.php" class="search-icon to-hide-mobile">rechercher</a>
                  <a href="panier.php" class="panier-icon">panier</a>

                  <button class="hamburger btn">
                    <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="37.719"
                    height="28.22"
                    viewBox="0 0 37.719 28.22"
                    >
                    <g
                    id="Groupe_94"
                    data-name="Groupe 94"
                    transform="translate(6391.387 218.246)"
                    >
                    <line
                    id="Ligne_11"
                    data-name="Ligne 11"
                    x2="33.719"
                    transform="translate(-6389.387 -216.246)"
                    fill="none"
                    stroke="#271b1b"
                    stroke-linecap="round"
                    stroke-width="4"
                    />
                    <line
                    id="Ligne_14"
                    data-name="Ligne 14"
                    x2="29.137"
                    transform="translate(-6384.806 -204.136)"
                    fill="none"
                    stroke="#271b1b"
                    stroke-linecap="round"
                    stroke-width="4"
                    />
                    <line
                    id="Ligne_13"
                    data-name="Ligne 13"
                    x2="33.719"
                    transform="translate(-6389.387 -192.026)"
                    fill="none"
                    stroke="#271b1b"
                    stroke-linecap="round"
                    stroke-width="4"
                    />
                  </g>
                </svg>
              </button>
            </nav>
          </header>


          **************************************************
          <?php 
          if (isset($_POST['dam'])) {

            $emaill = escape_string($_POST['emaill']);
            $passwordd =escape_string(sha1($_POST['passwordd']));


            $sql=" SELECT * FROM abonnee WHERE email= '$emaill' AND password = '$passwordd' LIMIT 1  ";
        // LIMIT 1 cest une facon de dire je veut en retourner 1 seul
            $result=query($sql);
            $user=fetch_array($result);



            if ($user  != null)  {
              $_SESSION['logged']=true;
              $_SESSION['nom']=$user['nom'];
              $_SESSION['id']=$user['id'];

              redirect("index.php");
            }else{
              echo "ereur ";
            }
          }

          ?> 
          **********************************************************************
          <?php require("functions.php");?>
          <!DOCTYPE html>
          <html lang="en">
          <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Document</title>
            <link rel="stylesheet" href="shared/all/css/all.css">
            <link rel="stylesheet" href="shared/fullProductCard/css/fullProductCard.css">
            <link rel="stylesheet" href="panier-profil/shared/css/shared.css">
            <link rel="stylesheet" href="panier-profil/panier/css/panier.css">

          </head>
          <body>
            <?php include("header.php") ?>
    <!-- <div class=" product-full-card flex center-justify wrap__ ">
        <div class="close-btn-wrapper">
        
            <button class="close-btn x-icon flex-center r50"></button>
        </div>
        
            <div class="product-img-wrapper">
                <img src="**" alt="" class="product-img">
                <button class="lightbox-btn"></button>
        
            </div>
            <div class="right sec-txt">
                <p class="product-name main-txt">**</p>
                <div class="description-wrapper">
                    Description : 
                    <p class="product-description main-txt">
                       **
                    </p>

                </div>
                
                <div class="price-wrapper iflex-center">
                    Prix : <p class="product-price b">**</p>
        
                </div>
            
                
            </div>
            
        
        </div>
      -->

      <h2 class="section-title uppercase center-text">
        <span data-text="gerez votre panier" class="iflex-center">
          gerez votre panier

        </span>

      </h2>

      <div class="container">
        <div class="sections-wrapper ">
          <input type="radio" name="r" id="checkbox" class="HIDDEN" checked>
          <input type="radio" name="r" id="checkbox2" class="HIDDEN">
          <div class="buttons-wrapper flex-center wrap__">

            <label for="checkbox"  class="tab-btn left-label">Votre panier</label>
            <label for="checkbox2" class="tab-btn right-label"> Publications enregistées</label>
          </div>
          <div class="sections ">
            <div class="sections-content flex">

              <div class="left-section ">
                <p class="section-description center-text">
                  <span class="number">12</span> éléments dans votre panier
                </p>

                <div class="items">
                  <div class="product-card flex-center wrap__  r3">
                    <div class="left flex center-justify wrap__">
                      <img class="product-img r2" src="https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=689&q=80" alt="" class="product-img r3">
                      <div class="product-infos">
                        <p class="info-wrapper product-name">Montre Lorem ipsum dolor sit amet consectetur</p>
                        <p class="info-wrapper iflex-center">Prix : <span class="product-price">
                          12
                        </span></p>
                        <p class="info-wrapper quantity-wrapper">
                          Quantité : <span >
                            <button class="btn less">-</button>
                            <span class="quantity">1</span>
                            <button class="btn more">+</button>
                          </span>
                        </p>
                        <p class="info-wrapper montant-total-wrapper">Montant total : <span class="montant-total">12</span> DA</p>
                        <p class="product-description HIDE">
                          voici ma description *** jes uis un pc gamer avec ***
                          16gb de ram ***
                          3gb de cartge graphique ***
                          Un ecran 4K ***
                        </p>


                        <button class="btn read-more r1">Savoir plus</button>
                      </div>

                    </div>
                    <div class="right buttons-wrapper flex-center column">
                      <button class="long-btn-r validate action-btn ok-icon">Valider achat 

                      </button>
                      <button class="long-btn-r cancel action-btn  x-icon">Supprimer article

                      </button>

                    </div>
                  </div>






                </div>

              </div>
              <div class="right-section ">
                <p class="section-description center-text">
                  <span class="number">12</span> publications sauvgardés
                </p>
                <div class="items">
                  <div class="product-card flex-center wrap__  r3">
                    <div class="left flex center-justify wrap__">
                      <img class="product-img r2" src="https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=689&q=80" alt="" class="product-img r3">
                      <div class="product-infos">
                        <p class="info-wrapper product-name">Montre Lorem ipsum dolor sit amet consectetur</p>
                        <p class="info-wrapper iflex-center">Prix : <span class="product-price">
                          12
                        </span></p>
                        <p class="info-wrapper">
                         Email : <span class="pub-email">johnDoe@gmail.com</span> 
                       </p>
                       <p class="info-wrapper">
                         Numero : <span class="pub-tel">+213 000000000</span> 
                       </p>

                       <p class="product-description HIDE">
                        voici ma description *** jes uis un pc gamer avec ***
                        16gb de ram ***
                        3gb de cartge graphique ***
                        Un ecran 4K ***
                      </p>


                      <button class="btn read-more r1">Savoir plus</button>
                    </div>

                  </div>
                  <div class="right buttons-wrapper flex-center column">

                    <button class="long-btn-r cancel action-btn  x-icon">Supprimer la piblication

                    </button>

                  </div>
                </div>



              </div>
            </div>
          </div>

        </div>


      </div>

    </div>


  </div>
  <?php include("footer.php") ?>
</body>
<script src="shared/all/js/all.js"></script>
<script src="shared/fullProductCard/js/fullProductCard.js"></script>
<script src="panier-profil/panier/js/panier.js"></script>
</html>
*************************************************
 <!-- <div class=" product-full-card flex center-justify wrap__ ">
        <div class="close-btn-wrapper">
        
            <button class="close-btn x-icon flex-center r50"></button>
        </div>
        
            <div class="product-img-wrapper">
                <img src="**" alt="" class="product-img">
                <button class="lightbox-btn"></button>
        
            </div>
            <div class="right sec-txt">
                <p class="product-name main-txt">**</p>
                <div class="description-wrapper">
                    Description : 
                    <p class="product-description main-txt">
                       **
                    </p>

                </div>
                
                <div class="price-wrapper iflex-center">
                    Prix : <p class="product-price b">**</p>
        
                </div>
            
                
            </div>
            
        
        </div>
      -->
      ************************************************
      <?php 
      require("functions.php");

      ?>

      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" href="shared/all/css/all.css">
        <link rel="stylesheet" href="shared/fullProductCard/css/fullProductCard.css">
        <link rel="stylesheet" href="panier-profil/shared/css/shared.css">
        <link rel="stylesheet" href="panier-profil/panier/css/panier.css">

      </head>
      <body>
        <?php include("header.php") ?>

        <h2 class="section-title uppercase center-text">
          <span data-text="gerez votre panier" class="iflex-center">
            gerez votre panier

          </span>

        </h2>

        <div class="container">
          <div class="sections-wrapper ">
            <input type="radio" name="r" id="checkbox" class="HIDDEN" checked>
            <input type="radio" name="r" id="checkbox2" class="HIDDEN">
            <div class="buttons-wrapper flex-center wrap__">

              <label for="checkbox"  class="tab-btn left-label">Votre panier</label>
              <label for="checkbox2" class="tab-btn right-label"> Publications enregistées</label>
            </div>
            <div class="sections ">
              <div class="sections-content flex">

                <div class="left-section ">
                  <p class="section-description center-text">
                    <span class="number"> <?php  echo !empty($_SESSION['count']) ? $_SESSION['count']:"" ?></span> éléments dans votre panier
                    <br> <span class="montant-total">montant-total: <?php  echo !empty($_SESSION['totaux']) ? $_SESSION['totaux'].'DA':"" ?></span>
                  </p>
                  <?php echo $_SESSION['user_id']?>

                  <div class="items">

                    <div class="product-card flex-center wrap__  r3">
                      <div class="left flex center-justify wrap__">

                        <?php  
                        foreach ($_SESSION as $name => $product):
                          ?>
                          <?php  if (substr($name, 0,9)=='products_'):

                           ?>
                           <img class="product-img r2" src=" <?php  echo !empty($product['img']) ? $product['img']:"" ?>" alt="" class="product-img r3">
                           <div class="product-infos">
                            <p class="info-wrapper product-name"> produit:   <?php  echo !empty($product['nom']) ? $product['nom']:"" ?></p>

                            <p class="info-wrapper iflex-center">Prix : <span class="product-price">
                             <?php  echo !empty($product['prix']) ? $product['prix']:"" ?> 
                           </span></p><br>

                           <p class="info-wrapper iflex-center">Catégorie : <span class="">
                             <?php  echo !empty($product['categorie']) ? $product['categorie']:"" ?> 
                           </span></p>


                         </div>

                       </div>
                       <div class="right buttons-wrapper flex-center column">
                        <a href="#"><button class="long-btn-r validate action-btn ok-icon">       Enregistrer dans le panier

                        </button></a> 

                      </div>
                    </div>




                  <?php  endif;endforeach; ?>
                </div>


              </div>
              <div class="right-section ">
                <p class="section-description center-text">
                  <span class="number">12</span> publications sauvgardés
                </p>
                <div class="items">
                  <div class="product-card flex-center wrap__  r3">
                    <div class="left flex center-justify wrap__">
                      <img class="product-img r2" src="https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=689&q=80" alt="" class="product-img r3">
                      <div class="product-infos">
                        <p class="info-wrapper product-name">Montre Lorem ipsum dolor sit amet consectetur</p>
                        <p class="info-wrapper iflex-center">Prix : <span class="product-price">
                          12
                        </span></p>
                        <p class="info-wrapper">
                         Email : <span class="pub-email">johnDoe@gmail.com</span> 
                       </p>
                       <p class="info-wrapper">
                         Numero : <span class="pub-tel">+213 000000000</span> 
                       </p>

                       <p class="product-description HIDE">
                        voici ma description *** jes uis un pc gamer avec ***
                        16gb de ram ***
                        3gb de cartge graphique ***
                        Un ecran 4K ***
                      </p>


                      <button class="btn read-more r1">Savoir plus</button>
                    </div>

                  </div>
                  <div class="right buttons-wrapper flex-center column">

                    <a href="#"><button class="long-btn-r validate action-btn ok-icon">
                     valider l'achat

                   </button></a>

                   <a href="sup.php? id=<?php  echo !empty($product['id']) ? $product['id']:"" ?>"><button class="long-btn-r cancel action-btn  x-icon">Supprimer article

                   </button></a>

                 </div>
               </div>



             </div>
           </div> 
         </div>





       </div>


     </div>
     <?php include("footer.php") ?>
   </body>
   <script src="shared/all/js/all.js"></script>
   <script src="shared/fullProductCard/js/fullProductCard.js"></script>
   <script src="panier-profil/panier/js/panier.js"></script>
   </html>


++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Suuq.com</title>
  <link rel="stylesheet" href="shared/all/css/all.css">
  <link rel="stylesheet" href="shared/fullProductCard/css/fullProductCard.css">
  <link rel="stylesheet" href="panier-profil/shared/css/shared.css">
  <link rel="stylesheet" href="panier-profil/panier/css/panier.css">

</head>
<body>
 <?php include("header.php"); ?>
 <div class=" product-full-card flex center-justify wrap__ ">
  <div class="close-btn-wrapper">

    <button class="close-btn x-icon flex-center r50"></button>
  </div>

  <div class="product-img-wrapper">
    <img src="**" alt="" class="product-img">
    <button class="lightbox-btn"></button>

  </div>
  <div class="right sec-txt">
    <p class="product-name main-txt">**</p>
    <div class="description-wrapper">
      Description : 
      <p class="product-description main-txt">
       **
     </p>

   </div>

   <div class="price-wrapper iflex-center">
    Prix : <p class="product-price b">**</p>

  </div>


</div>


</div>


<h2 class="section-title uppercase center-text">
  <span data-text="gerez votre panier" class="iflex-center">
    gerez votre panier

  </span>

</h2>

<div class="container">
  <div class="sections-wrapper ">
    <input type="radio" name="r" id="checkbox" class="HIDDEN" checked>
    <input type="radio" name="r" id="checkbox2" class="HIDDEN">
    <div class="buttons-wrapper flex-center wrap__">

      <label for="checkbox"  class="tab-btn left-label">Votre panier</label>
      <label for="checkbox2" class="tab-btn right-label"> Publications enregistées</label>
    </div>
    <div class="sections ">
      <div class="sections-content flex">

        <div class="left-section ">
          <p class="section-description center-text">
            <span class="number"><?php  echo !empty($_SESSION['count']) ? $_SESSION['count']:"" ?></span> éléments dans votre panier
            <br> <span class="montant-total">montant-total: <?php  echo !empty($_SESSION['totaux']) ? $_SESSION['totaux'].'DA':"" ?></span>
          </p>



          <div class="items">
           <?php    foreach ($_SESSION as $name => $product):
            ?>
            <?php  if (substr($name, 0,9)=='products_'):

             ?>

             <div class="product-card flex-center wrap__  r3">
              <div class="left flex center-justify wrap__">
                <img class="product-img r2" src=" <?php  echo !empty($product['img']) ? $product['img']:"" ?>" alt="" class="product-img r3">
                <div class="product-infos">
                  <p class="info-wrapper product-name">Montre Lorem ipsum dolor sit amet consectetur</p>
                  <p class="info-wrapper iflex-center">Prix : <span class="product-price">
                   <?php  echo !empty($product['prix']) ? $product['prix']:"" ?> 
                 </span></p>

                 <p class="info-wrapper iflex-center">Catégorie : <span class="product-price">
                   <?php  echo !empty($product['categorie']) ? $product['categorie']:"" ?> 
                 </span></p>


                 <p class="product-description HIDE">
                  <?php  echo !empty($product['description']) ? $product['description']:"" ?>
                </p>


                <button class="btn read-more r1">Savoir plus</button>
              </div>

            </div>
            <div class="right buttons-wrapper flex-center column">
              <button class="long-btn-r validate action-btn ok-icon">Enregistrer dans le panier 

              </button>

            </div>
          </div>
        <?php  endif;endforeach; ?>

      </div>
    </div>
    <div class="right-section ">
      <p class="section-description center-text">
        <span class="number"></span> éléments dans votre panier$

      </p>
      <div class="items">
        <div class="product-card flex-center wrap__  r3">
          <div class="left flex center-justify wrap__">
            <img class="product-img r2" src="https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=689&q=80" alt="" class="product-img r3">
            <div class="product-infos">
              <p class="info-wrapper product-name">Montre Lorem ipsum dolor sit amet consectetur</p>
              <p class="info-wrapper iflex-center">Prix : <span class="product-price">
                12
              </span></p>
              <p class="info-wrapper">
               Email : <span class="pub-email">johnDoe@gmail.com</span> 
             </p>
             <p class="info-wrapper">
               Numero : <span class="pub-tel">+213 000000000</span> 
             </p>

             <p class="product-description HIDE">
              voici ma description *** jes uis un pc gamer avec ***
              16gb de ram ***
              3gb de cartge graphique ***
              Un ecran 4K ***
            </p>


            <button class="btn read-more r1">Savoir plus</button>
          </div>

        </div>
        <div class="right buttons-wrapper flex-center column">
          <button class="long-btn-r validate action-btn ok-icon">Valider l'Achat 

          </button>
          <button class="long-btn-r cancel action-btn  x-icon">Supprimer du panier 
          </button>

        </div>
      </div>



    </div>
  </div>
</div>

</div>


</div>

</div>


</div>

</body>
<script src="shared/all/js/all.js"></script>
<script src="shared/fullProductCard/js/fullProductCard.js"></script>
<script src="panier-profil/panier/js/panier.js"></script>
</html>






*******************************************************************
 <?php 
 include('functions.php');
 
 ?>

 <!DOCTYPE html>
 <html lang="en">
 <head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="shared/all/css/all.css">
  <link rel="stylesheet" href="shared/fullProductCard/css/fullProductCard.css">
  <link rel="stylesheet" href="panier-profil/shared/css/shared.css">
  <link rel="stylesheet" href="panier-profil/panier/css/panier.css">

</head>

<body>
  <?php include("header.php") ?>
 <!-- titre de page -->
<h2 class="section-title uppercase center-text">
  <span data-text="gerez votre panier" class="iflex-center">
    gerez votre panier

  </span>

</h2>

<div class="container">
  <div class="sections-wrapper ">
    <input type="radio" name="r" id="checkbox" class="HIDDEN" checked>
    <input type="radio" name="r" id="checkbox2" class="HIDDEN">
    <div class="buttons-wrapper flex-center wrap__">

      <label for="checkbox"  class="tab-btn left-label">Votre panier</label>
      <label for="checkbox2" class="tab-btn right-label"> Publications enregistées</label>
    </div>
    <div class="sections ">
      <div class="sections-content flex">

        <div class="left-section ">
          <p class="section-description center-text">
            <!-- recuperer la valeur de count que jai affecter a une varriable  de session  pour quelle soit visible dans tout les les pages de la meme session de site  idem pour le monntant total-->
            <span class="number"> <?php  echo !empty($_SESSION['count']) ? $_SESSION['count']:"" ?></span> éléments dans votre panier
            <br> <span class="montant-total">montant-total: <?php  echo !empty($_SESSION['totaux']) ? $_SESSION['totaux'].'DA':"" ?></span>
          </p>


          <div class="items">
            <!-- le  code suivant pour les item de nos cart -->

            <div class="product-card flex-center wrap__  r3">
              <div class="left flex center-justify wrap__">

                <?php  
                foreach ($_SESSION as $name => $product):
                  ?>
                  <?php  if (substr($name, 0,9)=='products_'):

                   ?>
                   <!-- recuperer les informations du produit -->
                   <img class="product-img r2" src=" <?php  echo !empty($product['img']) ? $product['img']:"" ?>" alt="" class="product-img r3">
                   <div class="product-infos">

                    <p class="info-wrapper product-name"> produit:   <?php  echo !empty($product['nom']) ? $product['nom']:"" ?></p>
                    
                    <p class="info-wrapper iflex-center">Prix : <span class="product-price">
                     <?php  echo !empty($product['prix']) ? $product['prix']:"" ?> 
                   </span></p><br>

                   <p class="info-wrapper iflex-center">Catégorie : <span class="">
                     <?php  echo !empty($product['categorie']) ? $product['categorie']:"" ?> 
                   </span></p>

                   <br><button class="btn read-more r1">Savoir plus</button>
                 </div>

               </div>
               <form action="panier.php" method="POST">
                <div class="right buttons-wrapper flex-center column">
                  <!-- lien pour sauvguarder le produit de le panier d'un utilisateur définit par son id -->
                  <a href=""><button class="long-btn-r validate action-btn ok-icon" name="enregistre">       Enregistrer dans le panier

                  </button></a> 

                </div>
              </form>
            </div>
            <!-- ***** form php d'ajouter et de enregistrer un produit   au panier ***** --> 
            <?php if(isset($_POST['enregistre'])){
              $utilisateur_id=escape_string($_SESSION['user_id']);
              $produit_id= escape_string($product['id']);

              $nom = escape_string($product['nom']);
              $prix = escape_string($product['prix']);
              $description =escape_string($product['description']);
              $categorie =escape_string($product['categorie']);
              $img = escape_string($product['img']);


              $sql="INSERT INTO  panier VALUES('','$utilisateur_id','$produit_id','$nom','$prix','$categorie','$img')";
              if (query($sql)) {
                echo " produit affecter vers le panier avec succé";
              }else{
               echo " produit non affecter au panier";
             }
           }



           ?>


         <?php  endif;endforeach; ?>
       </div>

     </div>




<!-- *************** cette section pour afficher les produit d'un utilisateur de session enregistrer dans le panier  -->

     <div class="right-section ">
      


            <div class="items">

             <?php
           $utilisateur_id  =$_SESSION['user_id'];
              $query="SELECT * FROM panier where utilisateur_id='$utilisateur_id'";
             $result =query($query);

             while ($row=fetch_array($result)):

               ?> 
               <div class="product-card flex-center wrap__  r3">
                <div class="left flex center-justify wrap__">
                  <img class="product-img r2" src=" <?php echo $row['img'] ?>" alt="" class="product-img r3">
                  <div class="product-infos">
                    <p class="info-wrapper product-name"> <?php echo $row['nom'] ?></p>
                    <p class="info-wrapper iflex-center">Prix :  <span class="product-price">
                     <?php echo $row['prix'] ?>
                   </span></p><br>
                   <p class="info-wrapper iflex-center">Catégorie :  <span class="product-pric">
                     <?php echo $row['categorie'] ?>
                   </span></p>

                   
                   


                   <button class="btn read-more r1">Savoir plus</button>
                 </div>

               </div>
               <div class="right buttons-wrapper flex-center column">

                <a href="#"><button class="long-btn-r validate action-btn ok-icon">
                 valider l'achat

                <form method="POST" action="panier.php"> 
                <button class="long-btn-r cancel action-btn  x-icon" name="send7">Supprimer l'article du panier

               </button>
                </form>
                <?php if (isset($_POST['send7'])) {
                $id=$product['id'];
                $sql="DELETE FROM panier
                WHERE id='$id'";
                if (query($sql)) {
                    echo "   le produit a était supprimer du panier avec succé";
                }else{
                   echo " erreur de suppression ";
               }
           }



 ?>

             </div>
           </div>

         <?php  endwhile; ?>

       </div>
     </div> 
   </div>

 </div>


</div>

</div>

</div>
<?php include("footer.php") ?>
</body>
<script src="shared/all/js/all.js"></script>
<script src="shared/fullProductCard/js/fullProductCard.js"></script>
<script src="panier-profil/panier/js/panier.js"></script>
</html>



*********************************************
<!-- dans  le cas ou je veut faire sup un produit -->

<?php

if(isset($_POST['supprimer']))
{
  if(isset($_POST['id']))
  {
    if(!empty($_POST['id']) AND is_numeric($_POST['id']))
    {
      $idproduit = htmlspecialchars(strip_tags($_POST['id']));

      try 
      {
        supprimer($id);
      } 
      catch (Exception $e) 
      {
        $e->getMessage();
      }



    }
  }
}
?>















