<?php

include("functions.php");



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Suuq.com</title>
    <link rel="chortcut icon"  href="images/suq.png">

    <link rel="stylesheet" href="shared/all/css/all.css">
    <link rel="stylesheet" href="forms/shared/css/formCommon.css">
    <link rel="stylesheet" href="forms/ajoutProduit/css/ajoutProduit.css">

</head>
<body>
   <?php include("header.php"); ?>
   
   <h2 class="section-title uppercase center-text">
    <span data-text="Ajouter produit" class="iflex-center">
        Ajouter produit 
    </span>

</h2>

<div class="container flex-center">

    <div class="form-wrapper  flex-center  dark-form wrap__ bg-blue r3">

        <div class="form-description r3">

            <p class="strong">
                Décrivez bien votre produit.
            </p>
            <p class="middle">   

                <h4>Exemple</h4>
                <div class="exemple flex wrap__">
                    <span class="prop">Nom :</span>
                    <span class="desc">
                        Pc Dell i5<br>
                        Tel OPPOA74 8gb/128gb
                    </span>
                </div>
                
                <div class="exemple flex wrap__">
                    <span class="prop">Description :</span>
                    <span class="desc">
                        Pc bon etat en marche depuis 2018<br>
                        RAM 8gb<br>
                        Processeue intel I5 5eme gen 
                        <br>
                        Carte graphique : NVDIA ..
                    </span>
                </div>
                <div class="exemple important flex wrap__ r3">
                    <span class="prop">!IMPORTANT :</span>
                    <span class="desc">
                        Vous pouvez utiliser *** pour inserer des sauts de ligne<br>
                        par exemple:<br>
                        <span class="important1 r2">
                            Marque : AZUS ** Processeur intel i5

                        </span>
                        
                        <span class="important2 r2">
                            sera affiché comme suit : 

                        </span>
                        
                        <div class="important1 r2">
                            Marque : AZUS <br> Processeur intel i5

                        </div>

                    </span>
                </div>
            </p>
            <div class="follow-description">
                <h2 class="title">SUIVEZ NOUS<br> 
                sur les réseaux sociaux</h2>

                <div class="social-links ">
                    <a href="" class="facebook-icon"></a>
                    <a href="" class="insta-icon"></a>
                </div>
            </div>
            
        </div>
        <?php if($_SESSION['logged']==true): ?>
        <?php if(isset($_POST['valider'])){
         
               
          


            $image = escape_string($_POST['image']);
            $nom = escape_string($_POST['nom']);
            $prix = escape_string($_POST['prix']);
            $description =escape_string ($_POST['description']);
            $categorie = escape_string($_POST['categorie']);
            

            
            $sql="INSERT INTO produitneuf VALUES('','$image','$nom','$prix','$description','$categorie')";
            if (query($sql)) {
                echo " produit ajouté avec succé";
            }else{
             echo "ereur d'ajout";
         }
     
     }

     ?>





     <form action="ajoutProduitneuf.php" method="post" class="flex-center column">
        <h2 class="title">Décrivez votre produit!</h2>

        <div class="form-segment">

            <div class="form-input-wrapper">
                <input type="text" name="nom" id="nom"  placeholder=" "required>
                <label for="nom">Nom produit:</label>
            </div>
            <div class="form-input-wrapper">
                <input type="text" name="prix" id="aprix"  placeholder=" "required>
                <label for="prix">Prix</label>
            </div>
            <div class="category-input-wrapper">
                <label for="niveau">Catégorie produit :</label>
                <select name="categorie" id="categorie"  required="" >
                  <?php $query="SELECT * FROM categorie";
                  $result =query($query);

                  while ($row=fetch_array($result)):

                   ?>
                   
                   
                   
                   <option value="echo $row['cat-title'] ?>" ><?php echo $row['cat-title'] ?></option>
                   
               <?php endwhile; ?>    
               
           </select>
           
       </div>
       <div class="img-file-input-wrapper">
        <div class="long-btn-r input-file-wrapper  flex center-align ">
         
            Ajouter une image
            <input type="file" label="" required id="image" name="image" class="img-file-input">
            <span class="input-file-icon"></span>
            
        </div>
        <p class="img-selected" style="color:#fff">
            image sélectionnée :
            <input type="name" class="form-control" name="image" required>

        </p>
    </div>


    <div class="form-input-wrapper" style="margin-top: 3em;">

     
        <textarea name="description" id="description"  ></textarea >
        <label for="description">Description</label>
    </div>


    <div class="nv-data-wrapper">
        <div class="nv-data-label-wrapper">

   <!-- <input type="checkbox" checked id="check"> <label class="" for="check" >  Les gens vous contacterons au numero et  adresse email enregistrés sur votre compte  </label>
     <div class="nv-data r2">
        <h4 class="title">Remplissez ce champ :</h4>
   <div class="form-input-wrapper">
    
       <input type="number"  name="numero" id="numero" placeholder=" ">
            <label for="description">Numero</label>
        </div> -->
      <!--   <div class="form-input-wrapper">
            <input type="text" name="posteur" id="posteur"  placeholder=" ">
            <label for="contact">Posteur:</label>
    
       <input type="email" name="contact" id="contact"  placeholder=" ">
            <label for="contact">Email</label>



    
            </div>
        
        </div> --> 
    </div>


</div>
<button class="long-btn-r bg-green" name="valider">valider</button>
</div>
</form>
<?php else:
    echo" Cher visiteur soyer les bien venus afin de mettre vos produit en vente vous devez vous inscrire  ou de vous connecter si vous étes déja abonnée chez nous";
redirect("ins.php");
 ?>
 <?php endif; ?>
</div>
</div>
<!-- php meme étape que l'inscription  -->



<?php include("footer.php") ?>
</body>
<script src="shared/all/js/all.js"></script>
<script src="forms/shared/js/addIcons.js"></script>
<script src="forms/ajoutProduit/js/ajoutProduit.js"></script>

</html>