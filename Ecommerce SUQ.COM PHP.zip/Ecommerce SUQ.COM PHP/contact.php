<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Suuq.com</title>
    <link rel="chortcut icon"  href="images/suq.png">

    <link rel="stylesheet" href="shared/all/css/all.css">
    <link rel="stylesheet" href="forms/shared/css/formCommon.css">
</head>
<body>

  <?php include("header.php"); ?>
      <h2 class="section-title uppercase center-text">
        <span data-text="contact" class="iflex-center">
            contact 
        </span>

    </h2>

    <div class="container flex-center">

    <div class="form-wrapper  dark-form flex-center  wrap__ bg-blue r3">

        <div class="form-description r3">

            <p class="strong">
                On dit que chaque bonne relation commence par une conversation.
            </p>
            <p class="middle">   
                <span class="message-icon"></span>
                Envoyez nous quelques lignes et on prendera plaisir à vous repondre dès que possible.</p>
            <div class="follow-description">
                <h2 class="title">SUIVEZ NOUS<br> 
                    sur les réseaux sociaux</h2>

                    <div class="social-links ">
                        <a href="" class="facebook-icon"></a>
                        <a href="" class="insta-icon"></a>
                    </div>
            </div>
            
        </div>
        <form action="" class="flex-center column">
            <h2 class="title">Exprimer vous !</h2>

            <div class="form-segment">

<div class="form-input-wrapper">
<input type="text" name="nom" id="nom"  placeholder=" "required>
<label for="nom">Nom</label>
</div>
<div class="form-input-wrapper">
<input type="text" name="adresseEmail" id="adresseEmail"  placeholder=" " required>
<label for="adresseEmail">Adresse email</label>
</div>
<div class="form-input-wrapper">


<textarea name="message" id="message"    required></textarea >
<label for="message">Message</label>
</div>

<button class="long-btn-r bg-green">Envoyer</button>
            </div>
        </form>
    </div>
</div>
<?php include("footer.php"); ?>
</body>
<script src="shared/all/js/all.js"></script>
<script src="forms/shared/js/addIcons.js"></script>


</html>