<?php include("functions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Suuq.com</title>
    <link rel="chortcut icon"  href="images/suq.png">
    <link rel="stylesheet" href="shared/all/css/all.css">
    <link rel="stylesheet" href="forms/shared/css/formCommon.css">
    <link rel="stylesheet" href="forms/connexion/css/sign.css">
</head>
<body>
  <?php include("header.php"); ?>
  <h2 class="section-title uppercase center-text">
    <span data-text="Connexion" class="iflex-center">
        Connexion 
    </span>

</h2>
<!-- .....ceci pour ce connecter -->


<div class="container flex-center">

    <div class="form-wrapper  dark-form flex-center  wrap__ bg-blue r3">

        <div class="form-description r3">
            <div class="top flex">
               <div class="left">
                <h2 class=" title strong center-text">
                    Vous avez déja un compte?
                </h2>
                <p class="middle center-text">   
                    Authentifier vous maintenant!
                </p>
                <div class="wrapper flex-center">

                    <button class="long-btn-r bg-blue toggle-state-btn">M'authentifier</button>
                </div>

            </div>
            <div class="right">
                <h2 class=" title strong center-text">
                    Vous n'avez pas de  compte?
                </h2>
                <p class="middle center-text">   
                    Inscriez vous maintenant!
                </p>
                <div class="wrapper flex-center">

                    <button class="long-btn-r bg-blue toggle-state-btn">M'inscrire</button>
                </div>
            </div>
        </div>

        <div class="bottom">
            <p class="center-text qst">
                <span>
                    Avez vous des questions ? <br> N'hésitez pas a nous contacter
                </span>
            </p>
            <div class="contact-call flex-center">

                <a href="contact.php" class="long-btn-r bg-blue">Nous contacter</a>

                <div class="social-links flex">
                    <a href="" class="facebook-icon"></a>
                    <a href="" class="insta-icon"></a>
                </div>
            </div>
        </div>


    </div>
    <div class="forms-wrapper flex">

<!-- isset fonction permet d'indiquer le test  si ona cliquer sur valider pour formulaire d'inscription faire ceci -->

        <?php if (isset($_POST['send'])) {
           //  recuperer les champ  passer par le formulaire d'inscription on utilisant 
           // la fonction escape string
            $email = escape_string($_POST['email']);
            $password =escape_string($_POST['password']);
            $nom =   escape_string($_POST['nom']); 
            $prenom = escape_string($_POST['prenom']); 
            $jour = escape_string($_POST['jour']);
            $mois = escape_string($_POST['mois']);
            $annee = escape_string($_POST['annee']);
            $numero = escape_string($_POST['numero']);
            $adress = escape_string($_POST['adress']);
            // declarer la requette sql QUI permet l'inscription
            $sql="INSERT INTO abonnee VALUES('','$email','$password','$nom','$prenom','$jour','$mois','$annee','$numero','$adress')";
            if (query($sql)) {
                echo "abonnée ajouter avec succé";
            }else{
               echo "ereur d'ajout ";
           }
       }

       ?>

       <form  class="flex-center column right" method="post" action="ins.php">
        <h2 class="title">M'inscrire !</h2>
        <div class="form-segments-wrapper">
            <div class="form-segments-content flex">

                <div class="form-segment">
                    <div class="form-input-wrapper">

                        
                        <input type="text" name="email" id="email"  placeholder=" " required>
                        <label for="email">Email</label>
                        
                    </div>
                    <span id="testemail"> </span>

                    <div class="form-input-wrapper">
                        <input type="password" name="password" id="password"  placeholder=" " required>
                        <label for="password">Mot de passe</label>
                    </div>
                    <span id="testpass"> </span>
                        <!-- <div class="form-input-wrapper">
                            <input type="password-confirm" name="password-confirm" id="password-confirm"  placeholder=" " required>
                            <label for="password-confirm">Confirmer votre mot de passe</label>
                        </div> -->
                        <button class="long-btn-r bg-green next-btn">Suivant</button>



                    </div>
                    <div class="form-segment">

                        <div class="form-input-wrapper">
                             <input type="text" name="nom" id="nom"  placeholder=" " required> 
                             <label for="nom">Nom</label>
                           
                           
                          </div>
                        <span id="testnom"> </span>
                        

                        <div class="form-input-wrapper">
                            <input type="text" name="prenom" id="prenom"  placeholder=" " required>
                            <label for="prenom">prenom</label>
                        </div>
                        <span id="testprenom"> </span>
                        <div class="birthday-wrapper">
                            <p class="white birth-label">
                                <span>
                                    Date de naissance
                                </span>
                            </p>

                            <div class="inputs-wrapper flex jc-space-between  wrap__">
                                <div class="form-input-wrapper">
                                    <input type="number" name="jour" id="jour" min="1" max="31"  placeholder=" " required>
                                    <label for="jour">Jour</label>
                                </div>
                                
                                <div class="form-input-wrapper">
                                    <input type="number" step="1" name="mois" id="mois" min="1" maxvalue="12"   placeholder=" " required>
                                    <label for="Mois">Mois</label>
                                </div>
                              
                                <div class="form-input-wrapper">
                                    <input type="number" name="annee" id="annee" min="1"   placeholder=" " required>
                                    <label for="annee">Année</label>
                                </div>
                              
                            </div>



                        </div>

                        <button class="long-btn-r bg-green next-btn">Suivant</button>
                        <button class="long-btn return-btn flex center-align r3">
                            <span class="return-back-icon"></span>
                        revenir en arriere</button>
                    </div>


                    <div class="form-segment">
                        <div class="form-input-wrapper">
                            <input type="text" name="numero" id="numero"  placeholder=" " required>
                            <label for="numero">numero tel</label>
                        </div>

                        <div class="form-input-wrapper">
                            <input type="adresse" name="adress" id="adress"  placeholder=" " required>
                            <label for="adress">adresse</label>
                        </div>

                        <button class="long-btn-r bg-green"  id="valider" name="send" value="valider">Valider</button>

                        <button class="long-btn return-btn flex center-align r3">
                            <span class="return-back-icon"></span>
                        revenir en arriere</button>

                    </div>

                </div>
            </div>



        </form>

       <?php include("login.php"); ?>

</div>


</div>
</div>
<?php include("footer.php"); ?>
</body>
<script src="ins.js"></script>
<script src="shared/all/js/all.js"></script>
<script src="forms/connexion/js/connexion.js"></script>

<script src="forms/shared/js/addIcons.js"></script>


</html>