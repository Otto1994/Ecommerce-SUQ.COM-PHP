 <footer class="container--">
      <div class="footer-content jc-space-between flex wrap__">
        <div class="col">
          <h4 class="footer-title">Contact</h4>
          <div class="col-txt">
            <p>Email : <span>suuq@gmail.com</span></p>

            <p>Tel : <span>0673.97.90.62</span></p>
            <a href="contact.html" class="long-btn-r bg-green">Nous Contacter</a>
          </div>
        </div>
        <div class="col-4">
          <h4 class="footer-title">Réseaux sociaux</h4>
          <div class="col-txt">
            <a href="#"><img src="images/facebook.png" alt="facebook" class="logo"></a>
            <a href="#"> <img src="images/twitter.png" alt="twitter" class="logo"></a>
            <a href="#"> <img src="images/youtube.png" alt="youtube" class="logo"></a>
          </div>
        </div>
        <div class="col">
          <h4 class="footer-title">Conditions d'utilisation</h4>
          <div class="col-txt">
            <p>
              Nous t'invitons a lire les condition d'utilisation de notre
              plateforme par <a href="conditionUtilisation.php">consulter sur </a>
            </p>
          </div>
        </div>
      </div>
      <div class="center-text copyrights">&copy; 2021 tout droits réservés</div>
    </footer>
