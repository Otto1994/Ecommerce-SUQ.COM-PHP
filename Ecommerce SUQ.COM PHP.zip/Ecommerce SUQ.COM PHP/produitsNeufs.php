<?php 

require("functions.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Suuq.com</title>
    <link rel="chortcut icon"  href="images/suq.png">
  <link rel="stylesheet" href="shared/all/css/all.css">
  <link rel="stylesheet" href="shared/carousel/css/carousel.css">
  <link rel="stylesheet" href="shared/fullProductCard/css/fullProductCard.css">
  <link rel="stylesheet" href="produits/shared/css/produits.css">
</head>
<body>
  <?php include("header.php") ;?>
  <!-- page affichage de produit code similaire a celui d'affichage des produit occas -->
  <div class=" product-full-card flex center-justify wrap__ "style="margin-top:12vh !important;" >
    <div class="close-btn-wrapper">

      <button class="close-btn x-icon flex-center r50"></button>
    </div>

    <div class="product-img-wrapper">
      <img src="**" alt="" class="product-img">
      <button class="lightbox-btn"></button>

    </div>
    <div class="right sec-txt">
      <p class="product-name main-txt">**</p>
      <div class="description-wrapper">
        Description : 
        <p class="product-description main-txt">
         **
       </p>

     </div>

     <div class="price-wrapper flex">
      Prix : <p class="product-price b">**</p>

    </div>

    <button class="add-to-cart btn ">

      <span class="add-circle r50 ib">+</span>
      <span>Ajouter au panier</span>
    </button>
  </div>


</div>
<section class="container">
  <h2 class="section-title uppercase center-text">
    <span data-text="produits neufs" class="iflex-center">
      produits neufs 

    </span>

  </h2>

  
  <div class="ourcarousel">
    <div class="carousel-header flex jc-space-between">
      <h3 class="carousel-title">publicité</h3>
      <a href="ajoutProduitneuf.php" class="carousel-btn long-btn-r">publier en vente plus de produit neuf</a>
    </div>
    

     <div class="carousel-content flex">

      <div class="product-card-wrapper ">
        <?php $query="SELECT * FROM produitneuf";
    $result =query($query);

    while ($row=fetch_array($result)):

     ?> 

        <div class="product-card new r3 ">
          <div class="top flex">
            <img src="<?php echo $row['image'] ?>" alt="" class="r3">
            <buton class="btn read-more ">Savoir plus</buton>

          </div>


          <div class="bottom r3 ">
            <p class="product-name "><?php echo $row['nom'] ?>,id:<?php echo $row['id'] ?></p>
            <p class="product-price ib">
              prix:<?php echo $row['prix'].'DA' ?>
            </p>
            <br> <p class="product-categorie ib">
             catégorie:<?php echo $row['categorie'] ?> 
           </p>

           <div class="product-description HIDE">
             description:<?php echo ($row['description'] )?>

           </div>
         </div>
         <div class="add-to-cart-wrapper r3">
          <form method="POST" action="chekoutneuf.php">
           <button class="add-to-cart btn  " style="margin-bottom:10px;">

            <span class="add-circle r40 ib"style="color:green; font-size:1.5rem; border-radius:50%;">+</span>
            <span>Ajouter au panier</span>
          </button>
          <input type="hidden" name="nom" value="<?php echo $row['nom'] ?>">
          <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
        </form>
        

      </div>
    






  </div>
<?php endwhile; ?>
</div>





</div>


</div>




</section>

<div class="container">
  <div class="product-category-change flex-center center-text column r3 ">

    <a href="produitsOccas.php" class="long-btn-r bg-green">Voir les produits d'occasion</a>
    <p>Découvrez les produits publiés 
    par d'autres utilisateurs </p>
  </div>
</div>

<?php include("footer.php"); ?>

</body>

<script src="shared/all/js/all.js"></script>
<script src="shared/carousel/js/carousel.js"></script>
<script src="shared/fullProductCard/js/fullProductCard.js"></script>

</html>
