 <?php 
 include('functions.php');
 
 ?>

 <!DOCTYPE html>
 <html lang="en">
 <head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Suuq.com</title>
    <link rel="chortcut icon"  href="images/suq.png">
  <link rel="stylesheet" href="shared/all/css/all.css">
  <link rel="stylesheet" href="shared/fullProductCard/css/fullProductCard.css">
  <link rel="stylesheet" href="panier-profil/shared/css/shared.css">
  <link rel="stylesheet" href="panier-profil/panier/css/panier.css">

</head>

<body>
  <?php include("header.php") ?>
 <!-- titre de page -->
<h2 class="section-title uppercase center-text">
  <span data-text="gerez votre panier" class="iflex-center">
    gerez votre panier

  </span>

</h2>

<div class="container">
  <div class="sections-wrapper ">
    <input type="radio" name="r" id="checkbox" class="HIDDEN" checked>
    <input type="radio" name="r" id="checkbox2" class="HIDDEN">
    <div class="buttons-wrapper flex-center wrap__">

      <label for="checkbox"  class="tab-btn left-label">Votre panier</label>
      <label for="checkbox2" class="tab-btn right-label"> Publications enregistées</label>
    </div>
    <div class="sections ">
      <div class="sections-content flex">

        <div class="left-section ">
          <p class="section-description center-text">
            <!-- recuperer la valeur de count que jai affecter a une varriable  de session  pour quelle soit visible dans tout les les pages de la meme session de site  idem pour le monntant total-->
            <span class="number"> <?php  echo !empty($_SESSION['count']) ? $_SESSION['count']:"" ?></span> éléments dans votre panier
            <br> <span class="montant-total">montant-total: <?php  echo !empty($_SESSION['totaux']) ? $_SESSION['totaux'].'DA':"" ?></span>
          </p>


          <div class="items">
            <!-- le  code suivant pour les item de nos cart -->

            <div class="product-card flex-center wrap__  r3">
              <div class="left flex center-justify wrap__">

                <?php  
                foreach ($_SESSION as $name => $product):
                  ?>
                  <?php  if (substr($name, 0,9)=='products_'):

                   ?>
                   <!-- recuperer les informations du produit -->
                   <img class="product-img r2" src=" <?php  echo !empty($product['img']) ? $product['img']:"" ?>" alt="" class="product-img r3">
                   <div class="product-infos">

                    <p class="info-wrapper product-name"> produit:   <?php  echo !empty($product['nom']) ? $product['nom']:"" ?></p>
                    
                    <p class="info-wrapper iflex-center">Prix : <span class="product-price">
                     <?php  echo !empty($product['prix']) ? $product['prix']:"" ?> 
                   </span></p><br>

                   <p class="info-wrapper iflex-center">Catégorie : <span class="">
                     <?php  echo !empty($product['categorie']) ? $product['categorie']:"" ?> 
                   </span></p>

                   <br><button class="btn read-more r1">Savoir plus</button>
                 </div>

               </div>
               <form action="panier.php" method="POST">
                <div class="right buttons-wrapper flex-center column">
                  <!-- lien pour sauvguarder le produit de le panier d'un utilisateur définit par son id -->
                  <a href=""><button class="long-btn-r validate action-btn ok-icon" name="enregistre">       Enregistrer dans le panier

                  </button></a> 

                </div>
              </form>
            </div>
            <!-- ***** form php d'ajouter et de enregistrer un produit   au panier ***** --> 
            <?php if(isset($_POST['enregistre'])){
              $utilisateur_id=escape_string($_SESSION['user_id']);
              $produit_id= escape_string($product['id']);

              $nom = escape_string($product['nom']);
              $prix = escape_string($product['prix']);
              $description =escape_string($product['description']);
              $categorie =escape_string($product['categorie']);
              $img = escape_string($product['img']);


              $sql="INSERT INTO  panier VALUES('','$utilisateur_id','$produit_id','$nom','$prix','$categorie','$img')";
              if (query($sql)) {
                echo " produit affecter vers le panier avec succé";
              }else{
               echo " produit non affecter au panier";
             }
           }



           ?>
<?php  endif;endforeach; ?>

         
       </div>

     </div>




<!-- *************** cette section pour afficher les produit d'un utilisateur de session enregistrer dans le panier  -->

     <div class="right-section ">
      


            <div class="items">

              <?php 
              if($_SESSION['logged']==true):?>
              <?php  $utilisateur_id=$_SESSION['user_id'];?>
             <?php $query="SELECT * FROM panier where utilisateur_id='$utilisateur_id'";
             $result =query($query);

             while ($row=fetch_array($result)):

               ?> 
               <div class="product-card flex-center wrap__  r3">
                <div class="left flex center-justify wrap__">
                  <img class="product-img r2" src=" <?php echo $row['img'] ?>" alt="" class="product-img r3">
                  <div class="product-infos">
                    <p class="info-wrapper product-name"> <?php echo $row['nom'] ?></p>
                    <p class="info-wrapper iflex-center">Prix :  <span class="product-price">
                     <?php echo $row['prix'] ?>
                   </span></p><br>
                   <p class="info-wrapper iflex-center">Catégorie :  <span class="product-pric">
                     <?php echo $row['categorie'] ?>
                   </span></p>

                   
                   


                   <button class="btn read-more r1">Savoir plus</button>
                 </div>

               </div>
               <div class="right buttons-wrapper flex-center column">

                <a href="#"><button class="long-btn-r validate action-btn ok-icon">
                 valider l'achat

               </button></a>
              <form method="POST" action="panier.php">
               <button class="long-btn-r cancel action-btn  x-icon">Supprimer article

               </button>
                 </form>
                 <?php if (isset($_POST['send7'])) {
                $id=$product['id'];
                $sql="DELETE FROM panier
                WHERE id='$id'";
                if (query($sql)) {
                    echo "   le produit a était supprimer du panier avec succé";
                }else{
                   echo " erreur de suppression ";
               }
           }
?>

     
             </div>
           </div>

    <?php  endwhile; ?>
    <?php else:
echo"Cher utilisateur  vous devez vous connecter pour consulter votre panier";
redirect("ins.php");
 ?>
     <?php endif;
      ?>
       </div>
     </div> 
   </div>

 </div>


</div>

</div>


</div>
<?php include("footer.php") ?>
</body>
<script src="shared/all/js/all.js"></script>
<script src="shared/fullProductCard/js/fullProductCard.js"></script>
<script src="panier-profil/panier/js/panier.js"></script>
</html>

