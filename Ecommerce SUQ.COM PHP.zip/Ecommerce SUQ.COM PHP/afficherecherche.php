<?php  include("functions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Suuq.com</title>
    <link rel="chortcut icon"  href="images/suq.png">
    <link rel="stylesheet" href="shared/all/css/all.css">
    <link rel="stylesheet" href="shared/carousel/css/carousel.css">
    <link rel="stylesheet" href="shared/fullProductCard/css/fullProductCard.css">
    <link rel="stylesheet" href="produits/shared/css/produits.css">
</head>
<body>
    <?php include("header.php");  ?>
  
   <div class=" product-full-card flex center-justify wrap__ " style="margin-bottom:10px;">
        <div class="close-btn-wrapper">
        
            <button class="close-btn x-icon flex-center r50"></button>
        </div>
        
            <div class="product-img-wrapper">
                <img src="**" alt="" class="product-img">
                <button class="lightbox-btn"></button>
        
            </div>
            <div class="right sec-txt">
                <p class="product-name main-txt">**</p>
                <div class="description-wrapper">
                    Description : 
                    <p class="product-description main-txt">
                       **
                    </p>

                </div>
                <div class="posteur-wrapper">

                    <p class="posteur-info">
                        Posté par: <span class="posteur-name main-txt b">**</span>
                    </p> 
                    <p class="posteur-info">
                        Email : <span class="posteur-email b">**</span>
                    </p> 
                 
                </div>
                <div class="price-wrapper flex">
                    Prix : <p class="product-price b">**</p>
        
                </div>
           
                <button class="add-to-cart btn ">
            
                    <span class="add-circle r50 ib">+</span>
                    <span>Ajouter au panier</span>
                </button>
           </form>
         </div>
            
        
        </div>


 

 <section class="container">
    <h2 class="section-title uppercase center-text">
        <span data-text="produits d'occasion" class="iflex-center">
        liste de produit rechercher

        </span>

    </h2>

    <div class="ourcarousel">

<div class="carousel-header flex jc-space-between">
    
</div>

<?php 

 
  $cherche =isset($_POST['cherche'])? escape_string($_POST['cherche']):"";
    $sql=" SELECT * FROM produitsocas  WHERE nom ='$cherche'";
 $result=query($sql);
 if ($count =mysqli_num_rows($result)>0): 
 while ($row=fetch_array($result)):

 ?>
      <div class="carousel-content flex">

      
                <div class="product-card-wrapper ">
                    <div class="product-card r3 ">
                        <div class="top flex">
                            <img src="<?php echo $row['image'] ?>"alt="" class="r3">
            <buton class="btn read-more ">Savoir plus</buton>

                        </div>
                        <div class="bottom r3 ">
                            <p class="product-name "> <?php echo $row['nom'] ?>,id:<?php echo $row['id'] ?> </p>
                            <p class="product-price ib">
                                prix:
                              <?php echo $row['prix'] ?>
                              
                            </p><br>
                            <p class="product-categorie ib">
                             catégorie:   <?php echo $row['categorie'] ?>
                              
                            </p> 
                           <br> <p class="product-etat ib">
                              Etat: <?php echo $row['etat'].'/10'  ?>
                              
                            </p>
                            <div class="posteur-wrapper">
                                <p class="posteur-info">
                                    posté par : <span class="posteur-name "> <?php echo $row['posteur'] ?></span>
                                
                                <p class="posteur-info">
                                    Email : <span class="posteur-email "><?php echo $row['contact'] ?></span>
                                </p>
                               
                            </div>
                           
                            <div class="product-description HIDE">
                               <!--  -->
                               <?php echo $row['description'] ?>
                            </div>
                        </div>
                        <form method="post" action="chekout.php" >
                        <div class="add-to-cart-wrapper r3">
                            <button class="add-to-cart btn  " name="btnpan" style="margin-bottom:10px;">
                            </button>

                            
                        </div>
                    </form>
                    </div>
                    
                </div>
               
                
               
       
            </div>
 <?php endwhile;endif;

?> 



         
            
        </div>
       
    
       
    
</section>



<?php include("footer.php"); ?>
</body>
<script src="shared/all/js/all.js"></script>
<script src="shared/carousel/js/carousel.js"></script>
<script src="shared/fullProductCard/js/fullProductCard.js"></script>
</html>