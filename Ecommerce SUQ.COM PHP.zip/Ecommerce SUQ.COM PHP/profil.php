
<?php  include("functions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Suuq.com</title>
    <link rel="chortcut icon"  href="images/suq.png">
    <link rel="stylesheet" href="shared/all/css/all.css">
    <link rel="stylesheet" href="shared/fullProductCard/css/fullProductCard.css">
    <link rel="stylesheet" href="panier-profil/shared/css/shared.css">
    <link rel="stylesheet" href="panier-profil/panier/css/panier.css">
    <link rel="stylesheet" href="forms/shared/css/others/formPresets.css">
    <link rel="stylesheet" href="panier-profil/profil/css/profil.css">
</head>
<body>
  <?php include("header.php"); ?>

  <div class=" product-full-card flex center-justify wrap__ ">
    <div class="close-btn-wrapper">

        <button class="close-btn x-icon flex-center r50"></button>
    </div>

    <div class="product-img-wrapper">
        <img src="**" alt="" class="product-img">
        <button class="lightbox-btn"></button>
        
    </div>
    <div class="right sec-txt">
        <p class="product-name main-txt">**</p>
        <div class="description-wrapper">
            Description : 
            <p class="product-description main-txt">
               **
           </p>

       </div>

       <div class="price-wrapper iflex-center">
        Prix : <p class="product-price b">**</p>
        
    </div>


</div>


</div>


<h2 class="section-title uppercase center-text">
    <span data-text="gerez votre panier" class="iflex-center">
        gerez vos informations personelles

    </span>

</h2>

<div class="container">
    <div class="sections-wrapper ">
        <input type="radio" name="r" id="checkbox" class="HIDDEN" checked>
        <input type="radio" name="r" id="checkbox2" class="HIDDEN">
        <div class="buttons-wrapper flex-center wrap__">

            <label for="checkbox"  class="tab-btn left-label">Vos informations</label>
            <label for="checkbox2" class="tab-btn right-label"> Vos publications</label>
        </div>
        <div class="sections ">
            <div class="sections-content flex">

                <div class="left-section ">
                    <p class="section-description center-text">
                      Modifiez vos informations personelles a tout moment 
                  </p>


                  <div class="forms-wrapper flex-center column">

                    <form action="profil.php" method="POST">
                        <div class="form-input-wrapper">
                            <input type="text" name="email" id="email" class="r2" placeholder=" " required value="monemail@gmail.com">
                            <label for="email">Email</label>
                        </div>

                        <button class="long-btn-r bg-green"name="send1">Sauvegarder</button>
                    </form>
                    <!-- ce code permet de recupérer mon email apartir de l'id passer en session  et le modifier en cas de click avec une requette sql -->

                    <?php if (isset($_POST['send1'])) {
                     if ($_SESSION['logged']==true) {
           //  recuperer les champ  passer par le formulaire d'inscription on utilisant 
           // la fonction escape string
                        $email = escape_string($_POST['email']);
                        $utilisateur_id=escape_string($_SESSION['user_id']);
            // declarer la requette sql QUI permet la modification
                        $sql="UPDATE abonnee SET email='$email' WHERE id='$utilisateur_id' ";
                        if (query($sql)) {
                            echo "email modifier avec succé";
                        }else{
                           echo " erreur de modification ";
                       }
                  }elseif ($_SESSION['logged']==false) {
   # code...
 
                    
                    echo"Cher utilisateur afin de modiffier les informations concernant votre compte vous devez d'abord se connecter";
                   }}

                   ?>
                   <form action="profil.php" method="POST">
                    <div class="form-input-wrapper">
                        <input type="password" name="passwordd" id="password" class="r2" placeholder=" " required >
                        <label for="passwordd">Mot de passe actuel</label>
                    </div>
                    <div class="form-input-wrapper">
                        <input type="password" name="passwordnew" id="password-new" class="r2" placeholder=" " required>
                        <label for="passwordnew">Nouveau mot de passe</label>
                    </div>
    <!-- <div class="form-input-wrapper">
        <input type="password" name="passwordconfirmation" id="password-confirmation" class="r2" placeholder=" " required>
        <label for="passwordconfirmation">Confirmer le Nouveau mot de passe</label>
    </div> -->
    <button class="long-btn-r bg-green" name="send2">Sauvegarder</button>

</form>
<!-- ce code permet de recupérer mon email apartir de l'id passer en session  et le modifier en cas de click avec une requette sql -->

<?php if (isset($_POST['send2'])) {
  if ($_SESSION['logged']==true) {
           //  recuperer les champ  passer par le formulaire d'inscription on utilisant 
           // la fonction escape string
    $passwordd= escape_string($_POST['passwordd']);
    $passwordnew= escape_string($_POST['passwordnew']);
    $utilisateur_id=escape_string($_SESSION['user_id']);
            // declarer la requette sql QUI permet la modification des champs
    $sql="UPDATE abonnee SET password='$passwordnew' WHERE id='$utilisateur_id'  
    AND password='$passwordd' ";
    if (query($sql)) {
        echo "password modifier avec succé";
    }else{
       echo " erreur de modification ";
   }
 }elseif ($_SESSION['logged']==false) {
   # code...
 
                    
                    echo"Cher utilisateur afin de modiffier les informations concernant votre compte vous devez d'abord se connecter";
                   }}

                   ?>



<form action="profil.php" method="POST">

    <div class="form-input-wrapper">
        <input type="text" name="nom" id="nom" class="r2" placeholder=" " required value="JOHN">
        <label for="nom">Nouveau Nom</label>
    </div>
    <div class="form-input-wrapper">
        <input type="text" name="prenom" id="prenom" class="r2" placeholder=" " required value="Doe">
        <label for="prenom"> nouvau prenom</label>
    </div>
    <div class="birthday-wrapper">
        <p class="birth-label">
            <span>
               Update Date de naissance
           </span>
       </p>

       <div class="inputs-wrapper flex jc-space-between  wrap__">
        <div class="form-input-wrapper">
            <input type="number" name="jour" id="Jour" min="1" max="31" class="r2" placeholder=" " required value="12">
            <label for="jour">Jour</label>
        </div>
        <div class="form-input-wrapper">
            <input type="number" name="mois" id="Mois" min="1" max="12" class="r2" placeholder=" " required value="2">
            <label for="Mois">Mois</label>
        </div>
        <div class="form-input-wrapper">
            <input type="number" name="annee" id="annee" min="1"  class="r2" placeholder=" " required value="1990">
            <label for="annee">Année</label>
        </div>
    </div>



</div>
<button class="long-btn-r bg-green" name="send3" >Sauvegarder</button>

</form>

<?php if (isset($_POST['send3'])) {
  if ($_SESSION['logged']==true) {
           //  recuperer les champ  passer par le formulaire d'inscription on utilisant 
           // la fonction escape string
    $nom= escape_string($_POST['nom']);
    $prenom= escape_string($_POST['prenom']);
    $jour= escape_string($_POST['jour']);
    $mois= escape_string($_POST['mois']);
    $annee= escape_string($_POST['annee']);

    $utilisateur_id=escape_string($_SESSION['user_id']);
            // declarer la requette sql QUI permet la modification des champs
    $sql="UPDATE abonnee SET nom='$nom',prenom='$prenom',jour='$jour',mois='$mois',annee='$annee' WHERE id='$utilisateur_id' ";
    if (query($sql)) {
        echo "informations personel modifier avec succé";
    }else{
       echo " erreur de modification ";
   }
}elseif ($_SESSION['logged']==false) {
   # code...
 
                    
                    echo"Cher utilisateur afin de modiffier les informations concernant votre compte vous devez d'abord se connecter";
                   }}

                   ?>


<form aaction="profil.php" method="POST">

    <div class="form-input-wrapper">
        <input type="text" name="numero" id="numero" class="r2" placeholder=" " required value="07********">
        <label for="numero">numero tel</label>
    </div>
    <button class="long-btn-r bg-green" name="send4">Sauvegarder</button>

</form>

<?php if (isset($_POST['send4'])) {
  if ($_SESSION['logged']==true) {
           //  recuperer les champ  passer par le formulaire d'inscription on utilisant 
           // la fonction escape string
    $numero= escape_string($_POST['numero']);

    $utilisateur_id=escape_string($_SESSION['user_id']);
            // declarer la requette sql QUI permet la modification des champs
    $sql="UPDATE abonnee SET numero='$numero' WHERE id='$utilisateur_id' ";
    if (query($sql)) {
        echo "numero modifier avec succé";
    }else{
       echo " erreur de modification ";
   }
 }elseif ($_SESSION['logged']==false) {
   # code...
 
                    
                    echo"Cher utilisateur afin de modiffier les informations concernant votre compte vous devez d'abord se connecter";
                   }}

                   ?>

<form action="profil.php" method="POST">

    <div class="form-input-wrapper">
        <input type="adresse" name="adress" id="adresse" class="r2" placeholder=" " required value="Bejaia">
        <label for="adress">adresse</label>
    </div>
    <button class="long-btn-r bg-green" name="send5">Sauvegarder</button>

</form>


<?php if (isset($_POST['send5'])) {
  if ($_SESSION['logged']==true) {
           //  recuperer les champ  passer par le formulaire d'inscription on utilisant 
           // la fonction escape string
    $adress= escape_string($_POST['adress']);

    $utilisateur_id=escape_string($_SESSION['user_id']);
            // declarer la requette sql QUI permet la modification des champs
    $sql="UPDATE abonnee SET adress='$adress' WHERE id='$utilisateur_id' ";
    if (query($sql)) {
        echo " adresse modifier avec succé";
    }else{
       echo " erreur de modification ";
   }
 }elseif ($_SESSION['logged']==false) {
   # code...
 
                    
                    echo"Cher utilisateur afin de modiffier les informations concernant votre compte vous devez d'abord se connecter";
                   }}

                   ?>
     

</div>


</div>
<div class="right-section ">
    <!-- <p class="section-description center-text">
        Vous avez publié 
        <span class="number">12</span> 
        publications
    </p> -->
    <!-- requette permet de recuperer tout  les article dans la table produitsocas -->


    <div class="items">
        <?php
        if ($_SESSION['logged']==true) :
        $email=$_SESSION['user_email'];

        $query="SELECT * FROM produitsocas WHERE contact='$email' ";
        // appel a la fonction query pou executer la requette 
        $result =query($query);
 // fetch_array: // on utilise fetch array() fonction php utiliser car:La fonction fetch_array() / mysqli_fetch_array() est une fonction intégrée en PHP qui récupère une ligne de résultat sous la forme d'un tableau associatif ou d'un tableau numérique 
        while ($row=fetch_array($result)):
            $_SESSION['id_p']=$row['id'];

            ?> 
            <div class="product-card flex-center wrap__  r3">
                <div class="left flex center-justify wrap__">
                    <img class="product-img r2" src="<?php echo $row['image'] ?>" alt="" class="product-img r3">
                    <div class="product-infos">
                        <p class="info-wrapper product-name"><?php echo $row['nom'] ?></p>
                        <p class="info-wrapper iflex-center">Prix : <span class="product-price">
                          <?php echo $row['prix'].'DA' ?>
                      </span></p>
                      <p class="info-wrapper">
                       Email : <span class="pub-email"><?php echo $row['contact'] ?></span> 
                   </p>


                   <p class="product-description HIDE">
                    <?php echo $row['description'] ?>

                </p>


                <button class="btn read-more r1">Savoir plus</button>
            </div>

        </div>
        <div class="right buttons-wrapper flex-center column">
            <button class="long-btn-r validate action-btn ok-icon">Modifier la publication

            </button>
            <form action="profil.php" method="POST">
                <button class="long-btn-r cancel action-btn  x-icon" name="send6">Supprimer la publication

                </button>
            </form>



            <?php if (isset($_POST['send6'])) {
              if ($_SESSION['logged']==true) {
             $ids=$_SESSION['id_p'];
                $sql="DELETE FROM produitsocas
                WHERE id='$ids'";
                if (query($sql)) {
                    echo "   le produit a était supprimer avec succé";
                }else{
                   echo " erreur de suppression ";
               }
           }}

           ?>



       </div>
   </div>


<?php endwhile;?>  
</div>
<?php else:
echo"Cher utilisateur  vous devez vous connecter pour consulter vos produit publier";
redirect("ins.php");
 ?>
  <?php endif; ?>
</div>
</div>

</div>


</div>

</div>


</div>
<?php include("footer.php"); ?>
</body>
<script src="shared/all/js/all.js"></script>
<script src="shared/fullProductCard/js/fullProductCard.js"></script>

</html>
