5<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Suuq.com</title>
    <link rel="chortcut icon"  href="images/suq.png">
    <link rel="stylesheet" href="shared/all/css/all.css">

    <style>

        ul{
            max-width: 600px;
            margin-inline: auto;
            line-height: 1.4;
        }
        li{
            list-style:circle;
            margin-block:1em
            }
    </style>
</head>
<body >
   

    <h2 class="section-title uppercase center-text">
        <span data-text="conditions d'utilisation" class="iflex-center"">
            conditions d'utilisation 
        </span>
    </h2>

    <h3 class="center-text">Suuq.com</h3>
    <ul >
        <li>Tout utilisateur abonné  du site doit respecter  certaines règles , et tout infraction  à ses règles peut valoir à des poursuite juridiques.</li>
        <li>La mise en vente d'article d'arnaque ,à caractère sexuel ou manquant de respect causera la supression du compte en concerné</li>

    </ul>
</body>
</html>