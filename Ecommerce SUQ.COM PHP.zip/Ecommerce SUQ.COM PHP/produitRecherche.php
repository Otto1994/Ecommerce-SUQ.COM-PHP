<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Suuq.com</title>
    <link rel="chortcut icon"  href="images/suq.png">
    <link rel="stylesheet" href="shared/all/css/all.css">
    <link rel="stylesheet" href="shared/carousel/css/carousel.css">
    <link rel="stylesheet" href="shared/fullProductCard/css/fullProductCard.css">
    <link rel="stylesheet" href="produits/shared/css/produits.css">
</head>
<body>
  <?php  include("header.php"); ?>


  <!-- cette page fonctionne toujourd avec le meme principe d'affichage des produit  -->
    <div class=" product-full-card flex center-justify wrap__ ">
        <div class="close-btn-wrapper">
        
            <button class="close-btn x-icon flex-center r50"></button>
        </div>
        
            <div class="product-img-wrapper">
                <img src="**" alt="" class="product-img">
                <button class="lightbox-btn"></button>
        
            </div>
            <div class="right sec-txt">
                <p class="product-name main-txt">**</p>
                <div class="description-wrapper">
                    Description : 
                    <p class="product-description main-txt">
                       **
                    </p>

                </div>
                <div class="posteur-wrapper">

                    <p class="posteur-info">
                        Posté par: <span class="posteur-name main-txt b">**</span>
                    </p>
                    <p class="posteur-info">
                        Email : <span class="posteur-email main-txt b">**</span>
                    </p>
                    <p class="posteur-info">
                        Tel : <span class="posteur-tel main-txt b">**</span>
                    </p>
                </div>
                <div class="price-wrapper flex">
                    Prix : <p class="product-price b">**</p>
        
                </div>
            
                <button class="add-to-cart btn ">
            
                    <span class="add-circle r50 ib">+</span>
                    <span>Ajouter au panier</span>
                </button>
            </div>
            
        
        </div>
<section class="container">
    <h2 class="section-title uppercase center-text">
        <span data-text="categories choisie" class="iflex-center">
            categories choisie 

        </span>

    </h2>

    <div class="ourcarousel">

<div class="carousel-header flex jc-space-between">
    <h3 class="carousel-title">Produits neufs</h3>
    <a href="" class="carousel-btn long-btn-r">voir plus</a>
</div>

        
            <div class="carousel-content flex">
                <div class="product-card-wrapper ">
                    <div class="product-card r3 new">
                        <div class="top flex">
                            <img src="https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=689&q=80" alt="" class="r3">
            <buton class="btn read-more ">Savoir plus</buton>

                        </div>
                        <div class="bottom r3 ">
                            <p class="product-name ">montre digitale</p>
                            <p class="product-price ib">
                                99
                            </p>
                           
                           
                            <div class="product-description HIDE">
                                a description for the product***
                                name : VESTE***
                                processuer : ----***
                            </div>
                        </div>
                        
                        <!-- <div class="add-to-cart-wrapper r3">
                            <button class="add-to-cart btn  ">
            
                                <span class="add-circle r50 ib">+</span>
                                <span>Ajouter au panier</span>
                            </button>
                            
                        </div> -->
            
                    </div>
                    
                </div>
               
                
               
       
            </div>
        
            
        </div>
    <div class="ourcarousel">

<div class="carousel-header flex jc-space-between">
    <h3 class="carousel-title">Produits d'occasion</h3>
    <a href="" class="carousel-btn long-btn-r">voir plus</a>
</div>

        
            <div class="carousel-content flex">
                <div class="product-card-wrapper ">
                    <div class="product-card r3 ">
                        <div class="top flex">
                            <img src="https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=689&q=80" alt="" class="r3">
            <buton class="btn read-more ">Savoir plus</buton>

                        </div>
                        <div class="bottom r3 ">
                            <p class="product-name ">montre digitale</p>
                            <p class="product-price ib">
                                99
                            </p>
                            <div class="posteur-wrapper">
                                <p class="posteur-info">
                                    posté par : <span class="posteur-name ">JOHN Lau</span>
                                </p>
                                <p class="posteur-info">
                                    Email : <span class="posteur-email ">JOHHN@gmail.com</span>
                                </p>
                                <p class="posteur-info">
                                    Tel : <span class="posteur-tel ">+213 000000</span>
                                </p>
                            </div>
                           
                            <div class="product-description HIDE">
                                a description for the product***
                                name : VESTE***
                                processuer : ----***
                            </div>
                        </div>
                        <div class="add-to-cart-wrapper r3">
                            <button class="add-to-cart btn  ">
            
                                <span class="add-circle r50 ib">+</span>
                                <span>Ajouter au panier</span>
                            </button>
                            
                        </div>
            
                    </div>
                    
                </div>
               
                
               
       
            </div>
        
            
        </div>
       
    
       
    
</section>



    <?php  include("footer.php")
    ; ?>
    
</body>
<script src="shared/all/js/all.js"></script>
<script src="shared/carousel/js/carousel.js"></script>
<script src="shared/fullProductCard/js/fullProductCard.js"></script>

</html>