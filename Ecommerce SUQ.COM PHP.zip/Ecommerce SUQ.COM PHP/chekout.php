<?php require("functions.php");

// recupérer l'id et le nomde peoduit depuis la page form
$id = escape_string($_POST['id']);
$nom = escape_string($_POST['nom']);
// definir la requette SQL permmet de récuperer les produit ocasion apartir de l'id
	$sql="SELECT * FROM produitsocas where id='$id'";
	// exicuter la requette en utilisant la fonction query
	$result=query($sql);
	// fetch array car le requette retourn plusilleur produit tableau
	$product=fetch_array($result);
	// if ($_SESSION['products_'.$id]['nom']==$_POST['nom']){
	// 	$message="vous avez deja  ajouter ce produit a votre panier"
	// 	// redirect("panier.php?message=".$message);
	// }

	$_SESSION['products_'.$product['$id']]=array(
		id=>$product['id'],
		img=>$product['image'],
		nom=>$product['nom'],
		prix=>$product['prix'],
		total=>$product['prix'],
		categorie=>$product['categorie'],
		description=>$product['description'],
        

	);
	// ligne designe le total prix d'achat et la 2eme nbr de produit dans la panier
	$_SESSION['totaux'] += $_SESSION['products_'.$product['$id']]['total'];
	$_SESSION['count'] +=1;
	redirect("panier.php");

?>