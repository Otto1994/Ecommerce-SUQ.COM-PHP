
<?php include("functions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Suuq.com</title>
    <link rel="chortcut icon"  href="images/suq.png">
    <link rel="chortcut icon"  href="images/suq.png">
    <link rel="stylesheet" href="shared/all/css/all.css">
    <link rel="stylesheet" href="forms/shared/css/formCommon.css">
    <link rel="stylesheet" href="forms/rechercheProduit/css/rechercher.css">
</head>
<body>

 <?php include("header.php"); 









 ?>
    <h2 class="section-title uppercase center-text">
        <span data-text="rechercher" class="iflex-center">
            rechercher article
        </span> 

    </h2>










    <div class="container flex-center">
<form action="afficherecherche.php" methode="POST" class="r3">

    <div class="form-input-wrapper">
        <input type="text" name="cherche" id="cherche"  placeholder=" "required>
        <label for="cherche">Mot clé</label>
        </div>

        <div class="bordered input-wrapper ">
            <p>Categorie</p>
           
    <select name="category-selecy" id="category-select"  required>
               <?php $query="SELECT * FROM categorie";
$result =query($query);



while ($row=fetch_array($result)):

 ?>
            <option value=""  ><?php echo $row['cat-title'] ?></option>
          
       <?php endwhile; ?>     
            
            </select>
            
        </div>
        <div class="bordered input-wrapper">
            <p>Etat du produit :</p>
            
            <label > <input type="radio" name="r" checked> Neuf</label>
            <br>
            <label > <input type="radio" name="r"> Occasion</label>

        </div>
       <!--  <div class="form-input-wrapper">
            <input type="number" name="prix-max" id="prix-max"  placeholder=" "required min="0">
            <label for="prix-max">Prix max</label>
            </div>
            <div class="form-input-wrapper">
                <input type="number" name="prix-min" id="prix-min"  placeholder=" "required min="0">
                <label for="prix-min">Prix min</label>
                </div> -->
        

<button class="long-btn-r bg-green" name="" value="" >Rechercher</button>
                
</form>
    
</div>
<?php include("footer.php"); ?>
</body>
<script src="shared/all/js/all.js"></script>

</html>