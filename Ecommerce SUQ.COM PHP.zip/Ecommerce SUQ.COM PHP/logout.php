<?php  
include("functions.php");

logout();
// function qui permet a un utilisateur de se déconnecter




 ?>