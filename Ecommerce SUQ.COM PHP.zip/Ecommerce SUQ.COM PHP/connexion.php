    

<?php 

  ob_start();
// definir les variable neccesaire
define("DB_HOST","localhost");
define("DB_USER","root");
define("DB_PASS","");
define("DB_NAME","suq-4");
// etablir la base de donnée
$connection = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);
mysqli_set_charset($connection,"utf8");


 ?>