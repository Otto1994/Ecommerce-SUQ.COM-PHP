  <?php 
session_start();
// toujour start la session ouvrire la sesssion 
ob_start();

  require('connexion.php');
// redireger  ma location dans le ssite vers une autres page
  function redirect ($location){
  	header("location:".$location);
  }
// function permet d'exicuter les requette on les liant a la connexion vers la base de donnée
  function query($sql){
  	global $connection;
  	return mysqli_query($connection,$sql);
  }

// function permet d'enlever ne pas prendre concederation des caractére special dan sune chaine de caractere
  function escape_string($string){
  	global $connection;
  	return mysqli_real_escape_string($connection,$string);
  } 
// traiter un tableau ligne par ligne
  function fetch_array($result){
  	return mysqli_fetch_array($result);
  }
  // function permet de détruire la session en cas déconnexion et la redirection vers index

  function logout(){
  	$_SESSION['logged']=false;
  	session_destroy();
  	redirect("index.php");

  }

  function empty_cart(){
  	unset($_SESSION['products_'.$id]);
  	$_SESSION['count']-=1;
  	$_SESSION['prix']-=1;
  	redirect("panier.php");
  }







  ?>