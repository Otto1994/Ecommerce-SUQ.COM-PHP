


<header class="container flex">
  <a href="" class="logo">
   <span class="text-primary " style="color: blue; font-size:1.5em; font-family:cursive;font-style: oblique;font-weight:bold;text-shadow:red;">      
   SUUQ.com </span>
 </a>
 <nav class="flex-center">
  <ul class="menu flex center-align">
    <button class="x-btn flex-center"></button>
    <li class="li"><a href="index.php">Acceuil</a></li>
    <li class="li"><a href="categories.php">Categories</a></li>
    <li class="global">
      <a class="btn">Produits</a>

      <ul class="sub-menu">
        <li><a href="produitsNeufs.php">Neufs</a></li>
        <li><a href="produitsOccas.php">Occasion</a></li>

      </ul>
    </li>
    <li class="li"><a href="contact.php">Nous Contacter</a></li>

    <li>
      <a href="profil.html" class="profil-icon to-hide-desktop">profil</a>
    </li>

    <li>
      <a href="rechercher.html" class="search-icon to-hide-desktop">rechercher</a>
    </li>

    <li>
      <input type="checkbox" id="scheme-checkbox" />
      <div class="scheme-label-wrapper iflex center-align">
        <label for="scheme-checkbox" class="ib btn"></label>
      </div>

    </li>
  </ul>


  <!-- <a href="ins.php" class="long-btn-r bg-blue">Compte</a> -->



  <div class="global">
    <a class="long-btn-r bg-blue">Compte</a>
    <!-- si connecter recupererr nom prenom de l'abonnée -->
    <?php if(isset($_SESSION['logged'])&& $_SESSION['logged']==true):
     ?>

     <ul class="sub-menu">
      <li><a href="profil.php" class="long-btn-r bg-blue" style=""> <?php echo $_SESSION['user_f']; ?> </a></li><br>
      <li><a href="logout.php" class="long-btn-r bg-blue">Déconnexion</a></li>

    </ul>
    <?php 
  else: ?>
 <ul class="sub-menu">
      <li><span><i class="fal fa-prescription-bottle-alt" style="color:white;"></i></span><a href="ins.php" class="long-btn-r bg-blue" style="">Se Connecter</a></li>
      <li><a href="ins.php" class="long-btn-r bg-blue">S'inscrire</a></li>

    </ul>

 <?php endif;?>



</div>
<a href="profil.php" class="profil-icon to-hide-mobile">profil</a>
<a href="rechercher.php" class="search-icon to-hide-mobile">rechercher</a>
<a href="panier.php" class="panier-icon">panier</a>
 <button class="hamburger btn">
  <svg
  xmlns="http://www.w3.org/2000/svg"
  width="37.719"
  height="28.22"
  viewBox="0 0 37.719 28.22"
  >
  <g
  id="Groupe_94"
  data-name="Groupe 94"
  transform="translate(6391.387 218.246)"
  >
  <line
  id="Ligne_11"
  data-name="Ligne 11"
  x2="33.719"
  transform="translate(-6389.387 -216.246)"
  fill="none"
  stroke="#271b1b"
  stroke-linecap="round"
  stroke-width="4"
  />
  <line
  id="Ligne_14"
  data-name="Ligne 14"
  x2="29.137"
  transform="translate(-6384.806 -204.136)"
  fill="none"
  stroke="#271b1b"
  stroke-linecap="round"
  stroke-width="4"
  />
  <line
  id="Ligne_13"
  data-name="Ligne 13"
  x2="33.719"
  transform="translate(-6389.387 -192.026)"
  fill="none"
  stroke="#271b1b"
  stroke-linecap="round"
  stroke-width="4"
  />
</g>
</svg>
</button> 
</nav>
</header>
