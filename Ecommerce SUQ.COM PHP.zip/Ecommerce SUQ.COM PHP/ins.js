var inpnom=document.getElementById("nom");
var spnom=document.getElementById("testnom")
inpnom.addEventListener('focus', function () {
	spnom.textContent="saisir votre nom"
	spnom.style.color='green';})
inpnom.addEventListener('blur', function(){
	if (inpnom.value=="") {
		spnom.textContent="chanmps nom oblgatoire";
		spnom.style.color="red";}
		else {
			spnom.textContent="";
			inpnom.value=inpnom.value.toUpperCase();} 	
		}

		)
var pr=document.getElementById('prenom');
var sppre= document.getElementById('testprenom');
pr.addEventListener ('focus', function () {
	sppre.textContent="rensiegnez le chump prenom"	;
	sppre.style.color='green';});
pr.addEventListener('blur',function() {
	if (pr.value=='') {
		sppre.textContent='le chumps prenom est obliguatoir';
		sppre.style.color='red';
	} else {
		sppre.textContent='';
		pr.value=pr.value.substring(0, 1).toUpperCase()+
		pr.value.substring(1,pr.value.length).toLowerCase();
	}

});

var pass=document.getElementById("password");
var spmdp=document.getElementById("testpass");

pass.addEventListener("input", function () {
	if (pass.value.length<=3) {
		spmdp.textContent="mot de passe faible";
		spmdp.style.color="red";
		pass.style.color="red";
	} else if (pass.value.length>3 && pass.value.length<8) {
		spmdp.textContent= 'mot de passe moyen';
		spmdp.style.color="orange";
		pass.style.color="orange";
	} else {
		spmdp.textContent= 'mot de passe fort';
		spmdp.style.color="green";
		pass.style.color="green";
		
	}{
		
	}
});
// traitement de l email
var maill=document.getElementById("email");
var testmaill=document.getElementById("testemail");
// la methode inndexoff en l utilise pour chercher un caractere dans une chaine de caractere
maill.addEventListener("input",function () {
	if (maill.value.indexOf("@")==-1) {
		testmaill.textContent="format e mail non respecter";
		testmaill.style.color="red";
		
	} else {
		testmaill.textContent="format e mail respecter";
		testmaill.style.color="green";
		
	}
})
var pass=document.getElementById("passwordd");
var spmdp=document.getElementById("testpasss");

pass.addEventListener("input", function () {
	if (pass.value.length<=3) {
		spmdp.textContent="mot de passe faible";
		spmdp.style.color="red";
		pass.style.color="red";
	} else if (pass.value.length>3 && pass.value.length<8) {
		spmdp.textContent= 'mot de passe moyen';
		spmdp.style.color="orange";
		pass.style.color="orange";
	} else {
		spmdp.textContent= 'mot de passe fort';
		spmdp.style.color="green";
		pass.style.color="green";
		
	}{
		
	}
});
// traitement de l email
var maill=document.getElementById("emaill");
var testmaill=document.getElementById("testemaill");
// la methode inndexoff en l utilise pour chercher un caractere dans une chaine de caractere
maill.addEventListener("input",function () {
	if (maill.value.indexOf("@")==-1) {
		testmaill.textContent="format e mail non respecter";
		testmaill.style.color="red";
		
	} else {
		testmaill.textContent="format e mail respecter";
		testmaill.style.color="green";
		
	}
})

