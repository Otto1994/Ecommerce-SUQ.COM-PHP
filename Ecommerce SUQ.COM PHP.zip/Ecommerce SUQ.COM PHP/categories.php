<?php include("functions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Suuq.com</title>
    <link rel="chortcut icon"  href="images/suq.png">
    <link rel="stylesheet" href="shared/all/css/all.css">
    <link rel="stylesheet" href="categories/css/categories.css">
</head>
<body>
 <?php include("header.php"); ?>    
    <h2 class="section-title uppercase center-text">
        <span data-text="Categories" class="iflex-center">
            Categories 
        </span>
    </h2>
<div class="categories-wrapper container flex-center wrap__">
    <!-- recuperer les categorie de table catégorie de la base de donée -->
     <?php $query="SELECT * FROM categorie";
     // appel fonction query our exicuter la requette   
$result =query($query);

while ($row=fetch_array($result)):

 ?>
    
<a href="" class="category-card flex-center r2">
    <!-- recuperer le titre -->
    <h3 class="title"><?php echo $row['cat-title'] ?></h3>
<!-- recuperer l'image pour les cart -->
<img src="<?php echo $row['img'] ?>" alt="" class="bg-img HIDE">
<!-- recuperer l'mage pour le fond -->
<img src="<?php echo $row['img'] ?>" alt="" class="overlay-img HIDE">
</a>      

<?php endwhile; ?> 




    </div>
<?php include("footer.php"); ?>
</body>
<script src="shared/all/js/all.js"></script>
<script src="categories/js/categories.js"></script>

</html>