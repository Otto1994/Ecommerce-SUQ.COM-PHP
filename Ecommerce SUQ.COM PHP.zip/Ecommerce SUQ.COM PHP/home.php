
<body>
    
    <section class="hero-section container flex center-align">
        
        <div class="text-content flex column">
            <h1 class="main-title">
                Faites votre <br>Suq!
            </h1>
            <p class="site-description">
             Notre plateforme SUUQ.com vous propose un moyen de faire votre marché avec les meilleurs produits d'actualité , et vous offre le moyen de mettre en vente un de vos bien , ou voir les produits postés par d'autres utilisateurs tout comme vous !
            </p>
            <div class="ctas-wrapper flex column ">
                <a href="" class="cta-btn main r1 flex-center ">
                    <span class="txt">

                        Acheter
                    </span>


                </a>
                <a href="" class="cta-btn secondary r1 flex-center ">
                    <span class="txt">
                        Vendre

                    </span>
                </a>
    
            </div>
        </div>
        

       
       
    </section>

    <section class="services-section container">
        <h2 class="section-title uppercase center-text">
            <span data-text="nos services" class="iflex-center"">
                nos services

            </span>

        </h2>

        <div class="service-cards ">
            <div class="service-card flex-center r3">
               <div class="service-txt-wrapper">

                   <h3 class="title uppercase">produits neufs</h3>
               <p>
                   Afin de completer un achat vous dever crier avant tout un compte. 
                   Mais vous pouvez tout de meme voir nos produits et les ajoter à votre liste préféré afin de les consulter ultérieurement
               </p>
               </div>

               <div class="service-img-wrapper flex-center r3">
                   <img src="https://images.unsplash.com/photo-1618354691551-44de113f0164?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=358&q=80" alt="">
                   <a href="produitsNeufs.html" class="long-btn-r bg-green  iflex center-align reverse max-c "> voir plus </a>
               </div>
               
            
            </div>
            <div class="service-card  flex-center reverse r3">
               <div class="service-txt-wrapper">

                   <h3 class="title uppercase">produits d'occasion</h3>
               <p>
                   Ici vous découvrer les  produits mis en vente par d'autres personnes.
                   Meme vous  , vous avez la capacité de poster une publication et chercher un vendeur pour un de vos biens
               </p>
               </div>
               

               <div class="service-img-wrapper flex-center r3">
<img src="https://images.unsplash.com/photo-1467043237213-65f2da53396f?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=334&q=80" alt="">
                   <a href="produitsOccas.html" class="long-btn-r bg-blue  iflex center-align reverse max-c"> voir plus </a>
               </div>
            
            </div>
        </div>
    </section>

    <section class="weeks-products container">
        
        <h2 class="section-title uppercase center-text">
            <span data-text="produits de la semaine" class="iflex-center"">
                produits de la semaine 

            </span>

        </h2>
<div class="ourcarousel">
    <div class=" product-full-card flex center-justify wrap__ ">
        <div class="close-btn-wrapper">
        
            <button class="close-btn x-icon flex-center r50"></button>
        </div>
        
            <div class="product-img-wrapper">
                <img src="**" alt="" class="product-img">
        
            </div>
            <div class="right sec-txt">
                <p class="product-name">**</p>
                <div class="description-wrapper">
                    Description : 
                    <p class="product-description main-txt">
                       **
                    </p>

                </div>
                
                <div class="price-wrapper flex">
                    Prix : <p class="product-price b">**</p>
        
                </div>
            
                <button class="add-to-cart btn ">
            
                    <span class="add-circle r50 ib">+</span>
                    <span>Ajouter au panier</span>
                </button>
            </div>
            
        
        </div>
    
        <div class="carousel-content flex">
            <div class="product-card-wrapper ">
                <div class="product-card new r3 ">
                    <div class="top flex">
                        <img src="https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=689&q=80" alt="" class="r3">
        <buton class="btn read-more ">Savoir plus</buton>

                    </div>
                    <div class="bottom r3 ">
                        <p class="product-name main-txt">montre digitale</p>
                        <p class="product-price ib">
                            99
                        </p>
                        
                       
                        <div class="product-description HIDE">
                            a description for the product***
                            name : PC***
                            processuer : i5***
                        </div>
                    </div>
                    <div class="add-to-cart-wrapper r3">
                        <button class="add-to-cart btn  ">
        
                            <span class="add-circle r50 ib">+</span>
                            <span>Ajouter au panier</span>
                        </button>
                        
                    </div>
        
                </div>
                
           
           
          
           
            
             
    
    
        </div>
    
</div>

    </section>
</body>