<?php include("functions.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Suuq.com</title>
    <link rel="chortcut icon"  href="images/suq.png">
    <link rel="stylesheet" href="shared/all/css/all.css">
    <link rel="stylesheet" href="shared/carousel/css/carousel.css">
    <link rel="stylesheet" href="shared/fullProductCard/css/fullProductCard.css">
    <link rel="stylesheet" href="produits/shared/css/produits.css">
</head>
<body>
  <?php include("header.php"); ?>

<!-- le code suivant represente le statut sur lequelle s'affiche le produit dans le cas ou on click sur savoir plus
 -->
   <div class=" product-full-card flex center-justify wrap__ " style="margin-bottom:10px;">
        <div class="close-btn-wrapper">
        
            <button class="close-btn x-icon flex-center r50"></button>
        </div>
        
            <div class="product-img-wrapper">
                <img src="**" alt="" class="product-img">
                <button class="lightbox-btn"></button>
        
            </div>
            <div class="right sec-txt">
                <p class="product-name main-txt">**</p>
                <div class="description-wrapper">
                    Description : 
                    <p class="product-description main-txt">
                       **
                    </p>

                </div>
                <div class="posteur-wrapper">

                    <p class="posteur-info">
                        Posté par: <span class="posteur-name main-txt b">**</span>
                    </p> 
                    <p class="posteur-info">
                        Email : <span class="posteur-email b">**</span>
                    </p> 
                 
                </div>
                <div class="price-wrapper flex">
                    Prix : <p class="product-price b">**</p>
        
                </div>
            
                <button class="add-to-cart btn ">
            
                    <span class="add-circle r50 ib">+</span>
                    <span>Ajouter au panier</span>
                </button>
            </div>
            
        
        </div>


 

 <section class="container">
    <!-- class bstrp container permet de limiter la section on laissant une bordure right et left -->
    <h2 class="section-title uppercase center-text">
        <!-- definition d'un titre -->
        <span data-text="produits d'occasion" class="iflex-center">
        liste de produit rechercher

        </span>

    </h2>

    <div class="ourcarousel">

<div class="carousel-header flex jc-space-between">
    <h3 class="carousel-title">publicité</h3> 
    <!-- le lien suivant est un lien qui nous trasmet vers une page d'ajout d'un produit ocasion -->
    <a href="ajoutProduitocas.php" class="carousel-btn long-btn-r">mettre en vente plus produit d'ocassion</a>
</div>
<!-- définir la requette sql qui permet de recuperer les produit ocasion -->
        <?php $query="SELECT * FROM produitsocas";
        // appel a la fonction query pour executer la requette sql 
$result =query($query);
 
 // fetch_array:Retourne un tableau qui correspond à la ligne lue ou FALSE s'il n'y a plus de lignes dans le jeu de résultats result
while ($row=fetch_array($result)):

 ?> 
 <!-- code pour orguaniser la carte -->
      <div class="carousel-content flex">

      
                <div class="product-card-wrapper ">
                    <div class="product-card r3 ">
                        <div class="top flex">
                            <!-- recupérer l'image a partir de la ligne couante -->
                            <!-- idem pour les autres attribut -->
                            <img src="<?php echo $row['image'] ?>"alt="" class="r3">
            <buton class="btn read-more ">Savoir plus</buton>

                        </div>
                        <div class="bottom r3 ">
                            <p class="product-name "> <?php echo $row['nom'] ?>,id:<?php echo $row['id'] ?> </p>
                            <p class="product-price ib">
                                prix:
                              <?php echo $row['prix'] ?>
                              
                            </p><br>
                            <p class="product-categorie ib">
                             catégorie:   <?php echo $row['categorie'] ?>
                              
                            </p> 
                           <br> <p class="product-etat ib">
                              Etat: <?php echo $row['etat'].'/10'  ?>
                              
                            </p>
                            <div class="posteur-wrapper">
                                <p class="posteur-info">
                                    posté par : <span class="posteur-name "> <?php echo $row['posteur'] ?></span>
                                
                                <p class="posteur-info">
                                    Email : <span class="posteur-email "><?php echo $row['contact'] ?></span>
                                </p>
                               
                            </div>
                           
                            <div class="product-description HIDE">
                               <!--  -->
                               <?php echo $row['description'] ?>
                            </div>
                        </div>
                       
                        <div class="add-to-cart-wrapper r3">
                            <a href="ajoutprodpanier.php"><button class="add-to-cart btn  " style="margin-bottom:10px;">
            
                                <span class="add-circle r40 ib"style="color:green; font-size:1.5rem; border-radius:50%;">+</span>
                                <span>Ajouter au panier</span>
                            </button></a>

                            
                        </div>
                       
                    </div>
                    
                </div>
               
                
               
       
            </div>
<?php endwhile; ?>
         
            
        </div>
       
    
       
    
</section>

<div class="container">
    <div class="product-category-change flex-center center-text column r3 ">
<!-- lien vers les produit neuf -->
        <a href="produitsNeufs.php" class="long-btn-r bg-green">Voir nos produits neufs</a>
        <p>Decouvez les produits neufs et d'actualité mis en ligne </p>
    </div>
</div>

<?php include("footer.php"); ?>
</body>
<script src="shared/all/js/all.js"></script>
<script src="shared/carousel/js/carousel.js"></script>
<script src="shared/fullProductCard/js/fullProductCard.js"></script>
</html>