 <?php 
        if (isset($_POST['val'])) {
          // test si click sur valider est realiser faire le suivant

         // recuperer l'email et le mot de passe saisit
          // la fonction escape string sert a:prend un gestionnaire de connexion et échappe la chaîne en fonction du jeu de caractères actuel.
            $emaill = escape_string($_POST['emaill']);
            $passwordd =escape_string($_POST['passwordd']);

// passer la requette sql qui permet de comparer
            $sql=" SELECT * FROM abonnee WHERE email= '$emaill' AND password= '$passwordd' ";
        // LIMIT 1 cest une facon de dire je veut en retourner 1 seul
            // executer la requette en utilisant la fonction prédefinit query
            $result=query($sql);
            // on utilise fetch array() fonction php utiliser car:La fonction fetch_array() / mysqli_fetch_array() est une fonction intégrée en PHP qui récupère une ligne de résultat sous la forme d'un tableau associatif ou d'un tableau numérique 
            $user=fetch_array($result);

          if ($user != null)  {

              $_SESSION['logged']=true;
              $_SESSION['user_nom']=$user['nom'];
              $_SESSION['user_prenom']=$user['prenom'];
              $_SESSION['user_id']=$user['id'];
              $_SESSION['user_email']=$user['email'];
               $_SESSION['user_f']=$_SESSION['user_nom'].' '. $_SESSION['user_prenom'];

                             redirect("index.php");
          }else{
              echo '<div class="alert alert-danger mt-2">mot de passe ou email incoorect </div>';
        }
         }

    ?> 
<!-- le suivant et le formulaire de login avec class prédefinit -->

    <form  class="flex-center column left" action="ins.php" method="POST">
        <h2 class="title">M'authentifier !</h2>
        <div class="form-segment">
            <div class="form-input-wrapper">
                <input type="email" required name="emaill" id="emaill"  placeholder=" " required>
                <label for="emaill">email</label>
            </div>
            <span id="testemaill"></span>
            <div class="form-input-wrapper">
                <input type="password" required name="passwordd" id="passwordd"  placeholder=" " required>
                <label for="passwordd">mot de passe</label>
            </div>
            <span id="testpasss"></span>
            <button class="long-btn-r bg-green" name="val" value="val" >Valider</button>

        </div>
    </form>
